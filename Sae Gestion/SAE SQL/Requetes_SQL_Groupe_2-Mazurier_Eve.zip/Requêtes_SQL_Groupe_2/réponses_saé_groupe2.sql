-- Voici le docuement répondant aux 4 questions posées de la saé -- 
-- Réalisé par le groupe n°2 de la saé

--Question 1: Les vols au départ de l’aéroport de Roissy - Charles de Gaulle
--Question 2:  Les aéroport français
--Question 3:  Les types d’avion des vols reliant l’aéroport CDG à JFK
--Question 4:  Les types et nombre de sièges des avions de la compagnie Air France

-- Question 1: 
SELECT * FROM aero_8 ; 
postgres=# SELECT * FROM aero_8 ;
 id_vol_8 | id_aero_dep | aero_arr |                nom_comp                | distance | num_avion | emissions_co2
----------+-------------+----------+----------------------------------------+----------+-----------+---------------
        1 |           8 | AAE      | Air Algerie (AH)                       |      882 |         3 |        123480
        2 |           8 | ABJ      | Air France (AF)                        |     3044 |        14 |        426160
        3 |           8 | ABJ      | Alitalia (AZ)                          |     3044 |        14 |        426160
        4 |           8 | ABV      | Air France (AF)                        |     2776 |        17 |        388640
        5 |           8 | ABV      | Delta Air Lines (DL)                   |     2776 |        17 |        388640
        6 |           8 | ABV      | KLM Royal Dutch Airlines (KL)          |     2776 |        16 |        388640
        7 |           8 | ABZ      | Air France (AF)                        |      598 |        26 |         83720
        8 |           8 | ABZ      | Alitalia (AZ)                          |      598 |        26 |         83720
        9 |           8 | ABZ      | Flybe (BE)                             |      598 |        35 |         83720
       10 |           8 | ADB      | Harmony Airways (HQ)                   |     1425 |        14 |        199500
       11 |           8 | ADB      | SunExpress (XQ)                        |     1425 |         3 |        199500
       12 |           8 | ADD      | Ethiopian Airlines (ET)                |     3465 |        14 |        485100
       13 |           8 | AGA      | easyJet (U2)                           |     1434 |        14 |        200760
       14 |           8 | AGP      | Air France (AF)                        |      922 |         3 |        129080
       15 |           8 | AGP      | easyJet (U2)                           |      922 |        14 |        129080
       16 |           8 | AGP      | Air Europa (UX)                        |      922 |         3 |        129080
       17 |           8 | AJA      | easyJet (U2)                           |      575 |        14 |         80500
       18 |           8 | ALG      | Air France (AF)                        |      851 |        14 |        119140
       19 |           8 | ALG      | Air Algerie (AH)                       |      851 |         3 |        119140
       20 |           8 | ALG      | KLM Royal Dutch Airlines (KL)          |      851 |        14 |        119140
       21 |           8 | ALG      | Aeroflot Russian Airlines (SU)         |      851 |        14 |        119140
       22 |           8 | ALG      | Aigle Azur (ZI)                        |      851 |        14 |        119140
       23 |           8 | AMM      | Air France (AF)                        |     2099 |        14 |        293860
-- Suite  --
-- Cette table contient toutes les informations concernant les départs de vol venant de Charles de Gaulle nom de code CDG 

-- Question 2:
SELECT * FROM aero_fr;
postgres=# SELECT * FROM aero_fr;
 id_vol_fr | id_aero_dep | aero_arr |               nom_comp               | distance | num_avion | emissions_co2
-----------+-------------+----------+--------------------------------------+----------+-----------+---------------
         1 |          10 | AAE      | Air Algerie ,(AH)                     |      866 |         8 |        121240
         2 |          10 | AAE      | Aigle Azur ,(ZI)                      |      866 |         9 |        121240
         3 |          10 | ABJ      | Corsairfly ,(SS)                      |     3024 |        18 |        423360
         4 |          10 | AGA      | Royal Air Maroc ,(AT)                 |     1413 |        25 |        197820
         5 |          10 | AGA      | Transavia France ,(TO)                |     1413 |         8 |        197820
         6 |          10 | AGF      | Airlinair ,(A5)                       |      325 |        33 |         45500
         7 |          10 | AGP      | Iberia Airlines ,(IB)                 |      901 |         8 |        126140
         8 |          10 | AGP      | Transavia France ,(TO)                |      901 |         8 |        126140
         9 |          10 | AGP      | Formosa Airlines ,(VY)                |      901 |         8 |        126140
        10 |          10 | AJA      | Air France ,(AF)                      |      563 |         9 |         78820
        11 |          10 | AJA      | Corse-Mediterranee ,(XK)              |      563 |         9 |         78820
        12 |          10 | ALC      | Iberia Airlines ,(IB)                 |      735 |         8 |        102900
        13 |          10 | ALC      | Formosa Airlines ,(VY)                |      735 |         8 |        102900
        14 |          10 | ALG      | Air Algerie ,(AH)                     |      831 |        25 |        116340
        15 |          10 | ALG      | Aigle Azur ,(ZI)                      |      831 |         8 |        116340
        16 |          10 | ARN      | Norwegian Air Shuttle ,(DY)           |      976 |         8 |        136640
        17 |          10 | ATH      | Transavia France ,(TO)                |     1307 |         8 |        182980
        18 |          10 | ATH      | easyJet ,(U2)                         |     1307 |         8 |        182980
        19 |          10 | AUR      | Airlinair ,(A5)                       |      264 |        33 |         36960
        20 |          10 | AYT      | Transavia France ,(TO)                |     1641 |         8 |        229740
        21 |          10 | BCN      | Iberia Airlines ,(IB)                 |      513 |         8 |         71820
        22 |          10 | BCN      | Formosa Airlines ,(VY)                |      513 |         8 |         71820
        23 |          10 | BES      | Air France ,(AF)                      |      311 |         9 |         43540
-- Suite  --
-- contient toutes les informations concernant les aéroports 58 français répértoriés

--Question 3:
select * from avions as AV INNER JOIN aero_8 as A8 ON A8.num_avion = AV.id_avion
WHERE A8.aero_arr like 'JFK';
sae_groupe2=# select * from avions as AV INNER JOIN aero_8 as A8 ON A8.num_avion = AV.id_avion
sae_groupe2-# WHERE A8.aero_arr like 'JFK';
 id_avion | numero_avion |    nom_avion    | nb_passagers_min | nb_passagers_max | type_avion | id_vol_8 | id_aero_dep | aero_arr |        nom_comp        | distance | num_avion | emissions_co2
----------+--------------+-----------------+------------------+------------------+------------+----------+-------------+----------+------------------------+----------+-----------+---------------
       19 |          343 | Airbus_A340_300 |              277 |              440 | ligne      |      240 |           8 | JFK      | Air France (AF)        |     3622 |        19 |        507080
        7 |          757 | Boeing_757      |              200 |              289 | ligne      |      241 |           8 | JFK      | Finnair (AY)           |     3622 |         7 |        507080
       19 |          343 | Airbus_A340_300 |              277 |              440 | ligne      |      242 |           8 | JFK      | Alitalia (AZ)          |     3622 |        19 |        507080
        7 |          757 | Boeing_757      |              200 |              289 | ligne      |      243 |           8 | JFK      | British Airways (BA)   |     3622 |         7 |        507080
       17 |          332 | Airbus_332      |              250 |              406 | ligne      |      244 |           8 | JFK      | Delta Air Lines (DL)   |     3622 |        17 |        507080
       10 |          767 | Boeing_767_300  |              218 |              350 | ligne      |      245 |           8 | JFK      | Etihad Airways (EY)    |     3622 |        10 |        507080
        7 |          757 | Boeing_757      |              200 |              289 | ligne      |      246 |           8 | JFK      | Iberia Airlines (IB)   |     3622 |         7 |        507080
       10 |          767 | Boeing_767_300  |              218 |              350 | ligne      |      247 |           8 | JFK      | Qatar Airways (QR)     |     3622 |        10 |        507080
       17 |          332 | Airbus_332      |              250 |              406 | ligne      |      248 |           8 | JFK      | XL Airways France (SE) |     3622 |        17 |        507080
        7 |          757 | Boeing_757      |              200 |              289 | ligne      |      249 |           8 | JFK      | US Airways (US)        |     3622 |         7 |        507080
(10 lignes)
-- Cette requête nous renvoie tout les départ de l'aeroport de Charles de Gaulle allant a l'aeroport JFK avec toutes les informations nécessaires

--Question 4:  Les types et nombre de sièges des avions de la compagnie Air France
SELECT A1.id_aero_dep, AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_1 AS A1 ON A1.id_aero_dep = AV.id_avion
WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion , A1.id_aero_dep 
UNION 
SELECT A2.id_aero_dep , AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_2 AS A2 ON A2.id_aero_dep = AV.id_avion
WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion , A2.id_aero_dep  
UNION 
SELECT A3.id_aero_dep,  AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_3 AS A3 ON A3.id_aero_dep = AV.id_avion
WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion  , A3.id_aero_dep
UNION 
SELECT A4.id_aero_dep, AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_4 AS A4 ON A4.id_aero_dep = AV.id_avion
WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion  , A4.id_aero_dep
UNION 
SELECT A5.id_aero_dep, AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_5 AS A5 ON A5.id_aero_dep = AV.id_avion
WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion , A5.id_aero_dep 
UNION 
SELECT A6.id_aero_dep , AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_6 AS A6 ON A6.id_aero_dep = AV.id_avion
WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion  , A6.id_aero_dep
UNION 
SELECT A7.id_aero_dep , AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_7 AS A7 ON A7.id_aero_dep = AV.id_avion
WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion  , A7.id_aero_dep
UNION 
SELECT A8.id_aero_dep , AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_8 AS A8 ON A8.id_aero_dep = AV.id_avion
WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion  , A8.id_aero_dep
UNION 
SELECT A9.id_aero_dep , AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_9 AS A9 ON A9.id_aero_dep = AV.id_avion
WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion  , A9.id_aero_dep;

sae_groupe_2=# SELECT A1.id_aero_dep, AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_1 AS A1 ON A1.id_aero_dep = AV.id_avion
sae_groupe_2-# WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion , A1.id_aero_dep
sae_groupe_2-# UNION
sae_groupe_2-# SELECT A2.id_aero_dep , AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_2 AS A2 ON A2.id_aero_dep = AV.id_avion
sae_groupe_2-# WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion , A2.id_aero_dep
sae_groupe_2-# UNION
sae_groupe_2-# SELECT A3.id_aero_dep,  AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_3 AS A3 ON A3.id_aero_dep = AV.id_avion
sae_groupe_2-# WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion  , A3.id_aero_dep
sae_groupe_2-# UNION
sae_groupe_2-# SELECT A4.id_aero_dep, AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_4 AS A4 ON A4.id_aero_dep = AV.id_avion
sae_groupe_2-# WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion  , A4.id_aero_dep
sae_groupe_2-# UNION
sae_groupe_2-# SELECT A5.id_aero_dep, AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_5 AS A5 ON A5.id_aero_dep = AV.id_avion
sae_groupe_2-# WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion , A5.id_aero_dep
sae_groupe_2-# UNION
sae_groupe_2-# SELECT A6.id_aero_dep , AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_6 AS A6 ON A6.id_aero_dep = AV.id_avion
sae_groupe_2-# WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion  , A6.id_aero_dep
sae_groupe_2-# UNION
sae_groupe_2-# SELECT A7.id_aero_dep , AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_7 AS A7 ON A7.id_aero_dep = AV.id_avion
sae_groupe_2-# WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion  , A7.id_aero_dep
sae_groupe_2-# UNION
sae_groupe_2-# SELECT A8.id_aero_dep , AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_8 AS A8 ON A8.id_aero_dep = AV.id_avion
sae_groupe_2-# WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion  , A8.id_aero_dep
sae_groupe_2-# UNION
sae_groupe_2-# SELECT A9.id_aero_dep , AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_9 AS A9 ON A9.id_aero_dep = AV.id_avion
sae_groupe_2-# WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion  , A9.id_aero_dep
sae_groupe_2-# ;
 id_aero_dep |  type_avion   | nombre_types
-------------+---------------+--------------
           4 | ligne         |            6
           5 | ligne         |            1
           1 | ligne         |          146
           2 | ligne         |            1
           8 | non_mentionne |          165
           3 | ligne         |            1
           9 | ligne         |            2
           7 | ligne         |            3
           6 | non_mentionne |            7
(9 lignes)
-- Cette requête donne le type de l'avion le plus utilisé par la compagnie Air France (AF) pour les aeroports 1 à 9 désignés par leur clé primaire--

SELECT AF.id_aero_dep, AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_fr AS AF ON AF.id_aero_dep = AV.id_avion
WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion , AF.id_aero_dep; 

sae_groupe_2=# SELECT AF.id_aero_dep, AV.type_avion ,  COUNT(type_avion) AS nombre_types FROM avions as AV INNER JOIN aero_fr AS AF ON AF.id_aero_dep = AV.id_avion
sae_groupe_2-# WHERE nom_comp = 'Air France (AF)' GROUP BY AV.type_avion , AF.id_aero_dep;
 id_aero_dep |  type_avion   | nombre_types
-------------+---------------+--------------
          10 | ligne         |           29
          11 | ligne         |           19
          12 | ligne         |           25
          13 | ligne         |           14
          14 | ligne         |            3
          15 | ligne         |            6
          16 | ligne         |           18
          18 | ligne         |            4
          19 | ligne         |            2
          20 | ligne         |            2
          21 | ligne         |            4
          22 | ligne         |            3
          23 | ligne         |            7
          25 | ligne         |            5
          26 | ligne         |            5
          27 | ligne         |            3
          28 | ligne         |            4
          29 | ligne         |            2
          30 | ligne         |            1
          31 | ligne         |            1
          32 | ligne         |            2
          33 | ligne         |            1
          37 | ligne         |            2
          24 | non_mentionne |            7
(24 lignes)
-- Cette requête donne le type de l'avion le plus utilisé par la compagnie Air France (AF) pour les aeroports français désignés par leur clé primaire--





