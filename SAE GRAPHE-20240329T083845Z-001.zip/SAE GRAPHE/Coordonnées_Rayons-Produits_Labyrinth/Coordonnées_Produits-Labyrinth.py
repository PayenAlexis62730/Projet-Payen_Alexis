#PAIN : (0,8) à (0,11)

"La flûte"                  "(0.8)"
"baguette traditionelle"    "(0.9)"
"baguette paysane"          "(0.9)"
"pain rond"                 "(0.10)"
"pain sportif"              "(0.10)"
"La baguette moulée"        "(0.11)"
"La baguette en épi"        "(0.11)"

#Frais : (0,0) à (11,0) et (0,0) à (0,5)

"jambon"                   "(10,0)"
"beurre"                   "(0,1)"
"crème fraîche"            "(0,2)"
"lardon"                   "(9,0)"
"yaourt"                   "(0,3)"
"fromage"                  "(8,0)"
"lait"                     "(0,4)"
"Tofu"                     "(7,0)"
"œufs"                     "(0,5)"
#Surgelé :(12,0) à (12,5) et (10,3) à (10,5)

"pizza"                   "(12,1) "
"frites"                  "(10,4)"
"Mini cheeseBurgers"      "(12,2)"

#Alcool :  (4,7) à (4,10)

"Pastis"                  "(4,8)"
"Cognac"                  "(4,8)"
"triple-sec"              "(4,9)"
"Vin"                     "(4,7)"
"vin blanc"               "(4,7)"
"Whisky"                  "(4,10)"
"Rhum"                    "(4,10)"

#Fleurs : (2,5)

"Muguets"                 "(2,5)"
"Rose"                    "(2,5)"
"marguerite"              "(2,5)"
"tulipe"                  "(2,5)"
"hibiscus"                "(2,5)"

#Boissons : (12,7) à (12,10)

"Rockstar"                "(12,7)"
"RedBull"                 "(12,7)"
"Coca"                    "(12,8)"
"Eau"                     "(12,9)"
"Fanta"                   "(12,8)"
"Orangina"                "(12,8)"
"café"                    "(12,10)"
"Ice Tea"                 "(12,9)"

#Salé : (2,7)

"chips"                   "(2,7)"
"bretzel"                 "(2,7)"
"pistaches"               "(2,7)"


#Non-Alimentaire : (6,2) à (6,5) et (8,2) à (8,5)

"Vetements"               "(6,2)"
"peluche"                 "(6,3)"
"jouets"                  "(6,3)"
"bricolage"               "(6,4)"
"Carglass"                "(6,5)"
"clavier"                 "(8,2)"
"caméra"                  "(8,3)"
"Produit_anti-insectes"   "(8,4)"
"nourriture animal"       "(8,5)"

#DPH : (8,7) à (8,10)

"lessive"                 "(8,7)"
"dentifrice"              "(8,10)"
"maquillage"              "(8,9)"
"Couche"                  "(8,8)"
"Démaquillant"            "(8,9)"
"papier-toilette"         "(8,7)"
"brosse à dent"           "(8,10)"
"rouge à lèvre"           "(8,9)"

#Viennoiserie : (6,7) à (6,10)

"croissant"               "(6,7)"
"pain au chocolat"        "(6,7)"
"brioche"                 "(6,8)"
"chausson aux pommes"     "(6,8)"
"donuts"                  "(6,9)"
"beignets"                "(6,9)"

#SEC : (10,7) à (10,10)

"Saucisson"               "(10,7)"
"Coppa"                   "(10,7)"
"Rosette"                 "(10,8)"
"Salami"                  "(10,9)"
"chorizo"                 "(10,9)"

#Spiritueux : (12,12)

"Jägermeister"            "(12,12)"
"Pinard"                  "(12,12)"
"Mezcal"                  "(12,12)"
"Brandy"                  "(12,12)"
"Tequilla"                "(12,12)"

#Fruits_légumes : (2,9) à (2,10)

"Banane"                  "(2,9)"
"Poire"                   "(2,9)"
"pomme"                   "(2,9)"
"ananas"                  "(2,9)"
"orange"                  "(2,9)"
"tomate"                  "(2,10)"
"brocoli"                 "(2,10)"
"choux-fleur"             "(2,10)"
"carotte"                 "(2,10)"
"petit pois"              "(2,10)"

#Bio : (0,6)
"Pomme_bio"               "(0,6)"
"Steack_Végetal"          "(0,6)"

#Promos : (2,12)
"Armagnac"                "(2,12)"
"avocat"                  "(2,12)"

#VVP : (2,2) à (2,3)

"LeParisien"              "(2,3)"
"LaVoixDuNord"            "(2,3)"
"France-Presse"           "(2,2)"
"Nord_Litoral"            "(2,2)"

#Produit_Temporaire : (4,3) à (4,5)

"Carte pokémon"           "(4,3)"
"PS5"                     "(4,4)"

#Frais_Temporaire :   (2,0) à (4.0)

"blanc de calmar"         "(2,0)"
"cuisse de grenouille"    "(2,0)"
"tapas"                   "(3,0)"
"escargots"               "(4,0)"