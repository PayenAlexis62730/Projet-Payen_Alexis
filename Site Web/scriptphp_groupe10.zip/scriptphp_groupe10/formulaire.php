<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style_formulaire.css" rel="stylesheet" />
    <title>Exploration de l'esport sur Rainbow Six Siege</title>
</head>

<body>
        <img class ="notre_logo" src="img/logo.png">
        <img class="logo_6" src="img/6OC_2022.png" alt="Logo" />

    <nav>
        <a href="acceuil.html">Accueil</a>
        <a href="explication.html">Avancement</a>
        <a href="carte.html"> Cartes </a>
        <a href="heros.php"> Héros </a>
        <a href="classements.php"> Classements </a>
        <a href="equipes.html"> Equipes </a>
        <a href="formulaire.php"> Votre tournoi </a>
    </nav>

<body>

    <main>

    <form action="traitement.php" method="post">

        <label for="equipe1">Nom Équipe 1:</label>
        <select id="equipe1" name="equipe1" onchange="disableSelectedTeam('equipe1', 'equipe2')">
            <option value="Wolves Esports">Wolves Esports</option>
            <option value="ACEND">ACEND</option>
            <option value="Deathrow">Deathrow</option>
            <option value="Exalty">Exalty</option>
            <option value="MalaGanxst">MalaGanxst</option>
            <option value="Maestria">Maestria</option>
            <option value="WAFWAF">WAFWAF</option>
            <option value="DeathroW_academy">DeathroW Academy</option>
        </select>

        <label for="equipe2">Nom Équipe 2:</label>
        <select id="equipe2" name="equipe2" onchange="disableSelectedTeam('equipe2', 'equipe1')">
            <option value="Wolves Esports">Wolves Esports</option>
            <option value="ACEND">ACEND</option>
            <option value="Deathrow">Deathrow</option>
            <option value="Exalty">Exalty</option>
            <option value="MalaGanxst">MalaGanxst</option>
            <option value="Maestria">Maestria</option>
            <option value="WAFWAF">WAFWAF</option>
            <option value="DeathroW_academy">DeathroW Academy</option>
        </select>

        <!-- fonction qui empeche de selectionner deux fois la même team -->
        <script>
            function disableSelectedTeam(sourceId, targetId) {
                var sourceSelect = document.getElementById(sourceId);
                var targetSelect = document.getElementById(targetId);
    
                var selectedOption = sourceSelect.options[sourceSelect.selectedIndex].value;
    
                for (var i = 0; i < targetSelect.options.length; i++) {
                    if (targetSelect.options[i].value === selectedOption) {
                        targetSelect.options[i].disabled = true;
                    } else {
                        targetSelect.options[i].disabled = false;
                    }
                }
            }
        </script>

        <label for="carteManche1">Carte Manche 1:</label>
        <select id="carteManche1" name="carteManche1">
            <option value="avion"> Avion </option>
            <option value="banque"> Banque </option>
            <option value="base "> Base </option>
            <option value="cafe"> Café </option>
            <option value="canal"> Canal </option>
            <option value="chalet"> Chalet </option>
            <option value="clubhouse"> Clubhouse </option>
            <option value="consulat"> Consulat </option>
            <option value="favela"> Favela </option>
            <option value="forteresse"> Forteresse </option>
            <option value="frontiere"> Frontiere </option>
            <option value="gratte_ciel"> Gratte Ciel </option>
            <option value="huit_clos"> Huit clos </option>
            <option value="laboratoire"> Laboratoire </option>
            <option value="littoral"> Littoral </option>
            <option value="maison"> Maison </option>
            <option value="oregon"> Oregon </option>
            <option value="outback"> Outback </option>
            <option value="parc"> Parc d'attraction </option>
            <option value="plaines"> Plaines </option>
            <option value="stade"> Stade </option>
            <option value="tour"> Tour </option>
            <option value="villa"> Villa </option>
            <option value="yatch"> Yatch </option>
        </select>

        <label for="carteManche2">Carte Manche 2:</label>
        <select id="carteManche2" name="carteManche2">
            <option value="avion"> Avion </option>
            <option value="banque"> Banque </option>
            <option value="base "> Base </option>
            <option value="cafe"> Café </option>
            <option value="canal"> Canal </option>
            <option value="chalet"> Chalet </option>
            <option value="clubhouse"> Clubhouse </option>
            <option value="consulat"> Consulat </option>
            <option value="favela"> Favela </option>
            <option value="forteresse"> Forteresse </option>
            <option value="frontiere"> Frontiere </option>
            <option value="gratte_ciel"> Gratte Ciel </option>
            <option value="huit_clos"> Huit clos </option>
            <option value="laboratoire"> Laboratoire </option>
            <option value="littoral"> Littoral </option>
            <option value="maison"> Maison </option>
            <option value="oregon"> Oregon </option>
            <option value="outback"> Outback </option>
            <option value="parc"> Parc d'attraction </option>
            <option value="plaines"> Plaines </option>
            <option value="stade"> Stade </option>
            <option value="tour"> Tour </option>
            <option value="villa"> Villa </option>
            <option value="yatch"> Yatch </option>
        </select>

        <label for="scoreManche1">Score total :</label>
        <select id="scoreManche1equipe1" name="scoreManche1Equipe1" onchange="updateOptions(this.value, 'scoreManche1equipe2')">
            <option value="0">0</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</options>
        </select>
        /
        <select id="scoreManche1equipe2" name="scoreManche1Equipe2" onchange="updateOptions(this.value, 'scoreManche1equipe1')" >
            <option value="0">0</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</options>
        </select>

        <!-- fonction qui permet de vérifier deux conditions -->
        <script>
        function updateOptions(selectedValue, otherSelectId) {
            var otherSelect = document.getElementById(otherSelectId);
            
            // Désactiver l'option correspondante dans l'autre équipe si la valeur sélectionnée est 3
            if (selectedValue === '3') {
                for (var i = 0; i < otherSelect.options.length; i++) {
                    if (otherSelect.options[i].value === '3') {
                        otherSelect.options[i].disabled = true;
                    }
                }
            } else {
                // Réactiver toutes les options dans l'autre équipe si la valeur n'est pas 3
                for (var i = 0; i < otherSelect.options.length; i++) {
                    otherSelect.options[i].disabled = false;
                }
            }

            // Vérifier un des deux équipes ont sélectionné 3
            var equipe1Value = document.getElementById('scoreManche1equipe1').value;
            var equipe2Value = document.getElementById('scoreManche1equipe2').value;

            var submitButton = document.getElementById('submitButton');
            submitButton.disabled = !(equipe1Value === '3' || equipe2Value === '3');
        }
    </script>
        <input type="submit" id="submitButton" value="Valider" disabled>    
        </form>

    </main>

    
    <footer>
        <p>Site créé par </p>
        <ul>
            <li> DUPUIS Brian | LELONG Thomas | MAZURIER Eve | PAYEN Alexis  </li>
            <li> <a href="mentions.html">Mentions légales</a> </li>
            <li> <a href="deconnexion.php" class="deconnexion-btn">Déconnexion</a> </li>
        </ul>
    </footer>

    <style>
        a{ color: #fff; }
        .deconnexion-btn {
            color: #fff;
            background-color: #e74c3c; 
            padding: 8px 16px; 
            text-decoration: none; 
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        
        .deconnexion-btn:hover {
            background-color: #c0392b;
        }
    </style>
</body>

</html>
