<?php
    session_start(); // Démarrer la session

    // Supprimer tous les résultats de la session
    unset($_SESSION['resultats']);

    // Redirection vers le formulaire
    header('Location: formulaire.php');
    exit();
?>
