<?php
$host = 'database';
$port = '5432';
$dbname = 'sae-esport';
$user = 'sae-esport';
$password = 'hkgvMekMlp2U'; 

try {
    $pdo = new PDO("pgsql:host=$host;port=$port;dbname=$dbname;user=$user;password=$password");
    echo "Connexion réussie!";
} catch (Exception $e) {
    echo "Erreur de connexion : " . $e->getMessage();
}
