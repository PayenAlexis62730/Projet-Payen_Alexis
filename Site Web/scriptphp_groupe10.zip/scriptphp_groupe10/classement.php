<?php
$host = 'database';
$port = '5432';
$dbname = 'sae-esport';
$user = 'sae-esport';
$password = 'hkgvMekMlp2U'; // Mettez votre mot de passe réel ici

try {
    $pdo = new PDO("pgsql:host=$host;port=$port;dbname=$dbname;user=$user;password=$password");

    // Requête SQL avec jointure pour récupérer les données du classement
    $sql = "SELECT c.id_combat, c.qualification, c.date_combat, c.equipea, c.equipeb, e.nom_equipe, c.score, ca.nom_carte 
    FROM combat AS c
    INNER JOIN equipe AS e ON c.equipe_gagnante = e.id_equipe
    INNER JOIN cartes as ca ON ca.id_carte = c.id_carte
    ORDER BY c.id_combat ASC;";



    $result = $pdo->query($sql);

    // Vérifier si la requête a été exécutée correctement
    if ($result !== false) {
        // Vérifier s'il y a des résultats
        if ($result->rowCount() > 0) {
            // Afficher les résultats dans un tableau
            echo "<table border='1'>";
            echo "<tr><th>ID Combat</th><th>Qualification</th><th>Date</th><th>Equipe A </th><th>Equipe B</th><th>Gagnant</th><th>Score</th><th>Carte</th></tr>";

            // Boucler à travers les résultats et afficher chaque ligne
            while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr> <td>" . $row["id_combat"] . "</td> <td>" . $row["qualification"] . "</td><td>" . $row["date_combat"] . "</td> <td>" . $row["equipea"] . "</td><td>" . $row["equipeb"] . "</td><td>" . $row["nom_equipe"] . "</td> <td>" . $row["score"] . "</td><td>" . $row["nom_carte"] . "</td></tr>";
            }

            echo "</table>";

        } else {
            echo "Aucun résultat trouvé.";
        }
    } else {
        echo "Erreur dans la requête SQL.";
    }
} catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
}
?>
