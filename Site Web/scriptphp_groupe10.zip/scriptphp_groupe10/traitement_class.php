<?php
$host = 'database';
$port = '5432';
$dbname = 'sae-esport';
$user = 'sae-esport';
$password = 'hkgvMekMlp2U'; // Mettez votre mot de passe réel ici
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style_classement.css" rel="stylesheet" />
    <title>Document</title>
</head>
<body>

    <header>
        <img class ="notre_logo" src="img/logo.png">
        <img class="logo_6" src="img/6OC_2022.png" alt="Logo" />
    </header>

    <nav>
        <a href="acceuil.html">Accueil</a>
        <a href="explication.html">Avancement</a>
        <a href="carte.html"> Cartes </a>
        <a href="heros.php"> Héros </a>
        <a href="classements.php"> Classements </a>
        <a href="equipes.html"> Equipes </a>
        <a href="formulaire.php"> Faites vos propres choix  </a>
    </nav>
        
    <?php
    try {
        $pdo = new PDO("pgsql:host=$host;port=$port;dbname=$dbname;user=$user;password=$password");

        if(isset($_POST['numero'])) {
            $numeroMatch = $_POST['numero'];
        
            // Utiliser la valeur dans la requête SQL
            $sql = "SELECT e.nom_equipe, j.nom_joueur, c.id_combat, c.date_combat, h.nom_heros, kill_joueur, mort_joueur 
                    FROM avoir_joue AS aj
                    INNER JOIN equipe AS e ON aj.id_equipe = e.id_equipe
                    INNER JOIN joueur as j ON aj.id_joueur = j.id_joueur
                    INNER JOIN combat as c ON aj.id_combat = c.id_combat
                    INNER JOIN heros as h ON h.id_heros = aj.id_heros
                    WHERE c.id_combat = $numeroMatch;";
            
            // Exécutez votre requête SQL ici et affichez les résultats comme nécessaire
        } else {
            echo "Veuillez sélectionner un numéro de match.";
        }



        $result = $pdo->query($sql);

        // Vérifier si la requête a été exécutée correctement
        if ($result !== false) {
            // Vérifier s'il y a des résultats
            if ($result->rowCount() > 0) {
                // Afficher les résultats dans un tableau
                echo "<table border='1'>";
                echo "<tr><th>Nom Equipe </th><th>Joueur</th><th>Combat</th><th>Date </th><th>Heros</th><th>Kill</th><th>Mort</th></tr>";

                // Boucler à travers les résultats et afficher chaque ligne
                while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr> <td>" . $row["nom_equipe"] . "</td> <td>" . $row["nom_joueur"] . "</td><td>" . $row["id_combat"] . "</td> <td>" . $row["date_combat"] . "</td><td>" . $row["nom_heros"] . "</td><td>" . $row["kill_joueur"] . "</td> <td>" . $row["mort_joueur"] . "</td></tr>";
                }

                echo "</table>";

            } else {

                echo "Aucun résultat trouvé.";
            }
        } else {
            echo "Erreur dans la requête SQL.";
        }
    } catch (PDOException $e) {
        echo "Erreur de connexion : " . $e->getMessage();
    }
    ?>


</body>
</html>