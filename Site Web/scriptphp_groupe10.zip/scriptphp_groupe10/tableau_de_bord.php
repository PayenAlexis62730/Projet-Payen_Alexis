<?php
session_start();

if (!isset($_SESSION['utilisateur_id'])) {
    header('Location: index.php');
    exit();
}

$utilisateur_id = $_SESSION['utilisateur_id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de Bord</title>
</head>
<body>
    <main>
        <h2>Bienvenue sur le tableau de bord</h2>
        <p>Bienvenu dans le site R6 vous pouvez choisir de vous deconnecter ou d'accéder au site ci-dessous</p>
        <a class="bouton" href="deconnexion.php">Se déconnecter</a>
        <a class="bouton" href="acceuil.html"> Accès au site </a>
    </main>
    
    
    <style>
    main {
        max-width: 1400px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        background-color: rgba(248, 248, 248, 0.75);
        border-radius: 8px;
    }
    
    body {
        font-family: 'Arial', sans-serif;
        font-size: 16px;
        margin: 0;
        padding: 0;
        background: url('img/r6.jpg') center/cover no-repeat fixed;
        background-color: rgba(250, 250, 250, 0.7);
        color: #333;
    }

    h2 {
        text-align: center;
        color: #2c3e50;
    }

    form {
        max-width: 400px;
        margin: 20px auto;
        padding: 20px;
        background-color: #3498db;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 15px;
        color: #fff;
    }

    label {
        display: block;
        margin-bottom: 8px;
        color: #fff;
    }

    input {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    a{color: #fff; }
        
    .bouton {
            color: #fff; /* Couleur du texte */
            background-color: #e74c3c; /* Couleur de fond */
            padding: 8px 16px; /* Espacement interne (haut/bas, gauche/droite) */
            text-decoration: none; /* Supprime le soulignement du lien */
            border-radius: 5px; /* Coins arrondis */
            transition: background-color 0.3s; /* Animation de transition de couleur de fond */
        }
        
    .bouton:hover {
            background-color: #c0392b; 
        }
>
</style>
</body>
</html>
