<?php
session_start(); // Démarrer la session

$messageErreur = ""; // Initialisation du message d'erreur à une chaîne vide
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style_classement.css" rel="stylesheet" />
    <title>Exploration de l'esport sur Rainbow Six Siege</title>
</head>

<body>
    <header>
        <img class="logo_6" src="img/6OC_2022.png" alt="Logo" />
    </header>

    <nav>
        <a href="acceuil.html">Accueil</a>
        <a href="explication.html">Avancement</a>
        <a href="carte.html"> Cartes </a>
        <a href="heros.php"> Héros </a>
        <a href="classements.php"> Classements </a>
        <a href="equipes.html"> Equipes </a>
        <a href="formulaire.php"> Votre tournoi </a>
    </nav>

    <main>

        <?php
        // Vérification si le formulaire a été soumis
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            // Récupération des données du formulaire
            $equipe1 = $_POST["equipe1"];
            $equipe2 = $_POST["equipe2"];

            // Vérification si cette paire d'équipes a déjà joué ensemble
            if (equipesOntDejaJoue($equipe1, $equipe2)) {
                $messageErreur = "Erreur : Ces deux équipes ont déjà joué ensemble.";
            } else {
                $carteManche1 = $_POST["carteManche1"];
                $carteManche2 = $_POST["carteManche2"];
                $scoreManche1Equipe1 = $_POST["scoreManche1Equipe1"];
                $scoreManche1Equipe2 = $_POST["scoreManche1Equipe2"];
                $scoreManche1 = $_POST["scoreManche1"];

                // Calcul de l'équipe avec le plus de points dans la manche 1
                $equipeGagnante = ($scoreManche1Equipe1 > $scoreManche1Equipe2) ? $equipe1 : $equipe2;

                // Stockage des résultats dans la session
                if (!isset($_SESSION['resultats'])) {
                    $_SESSION['resultats'] = array();
                }

                $_SESSION['resultats'][] = array(
                    "equipe1" => $equipe1,
                    "equipe2" => $equipe2,
                    "carteManche1" => $carteManche1,
                    "carteManche2" => $carteManche2,
                    "scoreManche1Equipe1" => $scoreManche1Equipe1,
                    "scoreManche1Equipe2" => $scoreManche1Equipe2,
                    "scoreManche1" => $scoreManche1,
                    "equipeGagnante" => $equipeGagnante,
                );

                // Ajout de cette paire d'équipes à la liste des équipes ayant joué ensemble
                ajouterEquipesJoue($equipe1, $equipe2);

                 // Enregistrement des résultats dans la base de données
                enregistrerResultatDansBDD($equipe1, $equipe2, $carteManche1, $carteManche2, $scoreManche1Equipe1, $scoreManche1Equipe2, $equipeGagnante);
            }

        }

        // Fonction pour enregistrer tout la base de donnée
        function enregistrerResultatDansBDD($equipe1, $equipe2, $carteManche1, $carteManche2, $scoreManche1Equipe1, $scoreManche1Equipe2, $equipeGagnante) {
            // Connexion à la base de données (à remplacer par vos propres informations de connexion)
            $host = 'database';
            $port = '5432';
            $dbname = 'sae-esport';
            $user = 'sae-esport';
            $password = 'hkgvMekMlp2U';
        
            try {
                $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $user, $password);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
                // Requête SQL d'insertion
                $sql = "INSERT INTO resultat_tournoi (equipe1, equipe2, carte_manche1, carte_manche2, score_manche1_equipe1, score_manche1_equipe2, equipe_gagnante)
                        VALUES (:equipe1, :equipe2, :carteManche1, :carteManche2, :scoreManche1Equipe1, :scoreManche1Equipe2, :equipeGagnante)";
        
                // Préparation de la requête
                $stmt = $pdo->prepare($sql);
        
                // Liaison des paramètres
                $stmt->bindParam(':equipe1', $equipe1);
                $stmt->bindParam(':equipe2', $equipe2);
                $stmt->bindParam(':carteManche1', $carteManche1);
                $stmt->bindParam(':carteManche2', $carteManche2);
                $stmt->bindParam(':scoreManche1Equipe1', $scoreManche1Equipe1);
                $stmt->bindParam(':scoreManche1Equipe2', $scoreManche1Equipe2);
                $stmt->bindParam(':equipeGagnante', $equipeGagnante);
        
                // Exécution de la requête
                $stmt->execute();
        
                // Fermeture de la connexion
                $pdo = null;
            } catch (PDOException $e) {
                echo "Erreur d'insertion dans la base de données: " . $e->getMessage();
            }
        }

        //Fonction pour voir si les 2 équipes se sont deja rencontrées 
        function equipesOntDejaJoue($equipe1, $equipe2) {
            if (!isset($_SESSION['equipesJoue'])) {
                $_SESSION['equipesJoue'] = array();
            }
        
            // Vérification si cette paire d'équipes a déjà joué ensemble
            foreach ($_SESSION['equipesJoue'] as $paires) {
                if (in_array($equipe1, $paires) && in_array($equipe2, $paires)) {
                    return true;
                }
            }
        
            return false;
        }
        

        function ajouterEquipesJoue($equipe1, $equipe2) {
            if (!isset($_SESSION['equipesJoue'])) {
                $_SESSION['equipesJoue'] = array();
            }

            // Ajout de cette paire d'équipes à la liste des équipes ayant joué ensemble
            $_SESSION['equipesJoue'][] = array($equipe1, $equipe2);
        }
        ?>

        <!-- Affichage des résultats -->
        <h2><u>Résultats</u></h2>

        <?php
        // Afficher le message d'erreur si présent
        if (!empty($messageErreur)) {
            echo "<p style='color:red;'>{$messageErreur}</p>";
        }

        

        // Affichage du tableau des résultats
        echo "<table border='1'>";
        echo "<tr><th>Équipe 1</th><th>Équipe 2</th><th>Carte Manche 1</th><th>Carte Manche 2</th><th>Score - Équipe 1</th><th>Score - Équipe 2</th><th>Équipe Gagnante</th></tr>";

        // Vérifier si $_SESSION['resultats'] est défini et n'est pas vide
        if (isset($_SESSION['resultats']) && is_array($_SESSION['resultats']) && count($_SESSION['resultats']) > 0) {
            // Boucle pour afficher les résultats de chaque match depuis la session
            foreach ($_SESSION['resultats'] as $resultat) {
                echo "<tr>";
                echo "<td>{$resultat['equipe1']}</td>";
                echo "<td>{$resultat['equipe2']}</td>";
                echo "<td>{$resultat['carteManche1']}</td>";
                echo "<td>{$resultat['carteManche2']}</td>";
                echo "<td>{$resultat['scoreManche1Equipe1']}</td>";
                echo "<td>{$resultat['scoreManche1Equipe2']}</td>";
                echo "<td>{$resultat['equipeGagnante']}</td>";
                echo "</tr>";
            }
        } else {
            // Afficher un message si $_SESSION['resultats'] est vide
            echo "<tr><td colspan='7'>Aucun résultat à afficher.</td></tr>";
        }
        // Vider l'historique des équipes jouées après avoir affiché les résultats
        $_SESSION['equipesJoue'] = array();

        echo "</table>";

        // Tableau des statistiques de victoires par équipe
        echo "<h2>Statistiques de Victoires par Équipe</h2>";
        echo "<table border='1'>";
        echo "<tr><th>Équipe</th><th>Nombre de Victoires</th></tr>";

        // Calcul des statistiques de victoires
        if (isset($_SESSION['resultats']) && is_array($_SESSION['resultats']) && count($_SESSION['resultats']) > 0) {
            $statistiques = array_count_values(array_column($_SESSION['resultats'], 'equipeGagnante'));

            // Affichage des statistiques de victoires
            foreach ($statistiques as $equipe => $victoires) {
                echo "<tr>";
                echo "<td>{$equipe}</td>";
                echo "<td>{$victoires}</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='2'>Aucune statistique à afficher.</td></tr>";
        }

        echo "</table>";

        //fonction pour supprimer les données de a bdd 
        function supprimerTout() {
            // Connexion à la base de données (à remplacer par vos propres informations de connexion)
            $host = 'database';
            $port = '5432';
            $dbname = 'sae-esport';
            $user = 'sae-esport';
            $password = 'hkgvMekMlp2U';
        
            try {
                $pdo = new PDO("pgsql:host=$host;dbname=$dbname", $user, $password);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
                // Requête SQL de suppression de toutes les données
                $sql = "DELETE FROM resultat_tournoi";
        
                // Exécution de la requête
                $pdo->exec($sql);
        
                // Fermeture de la connexion
                $pdo = null;
            } catch (PDOException $e) {
                echo "Erreur de suppression dans la base de données: " . $e->getMessage();
            }
        }

        // Vérification si le bouton "Supprimer tout" a été cliqué
        if (isset($_POST['supprimer'])) {
            // Appel de la fonction de suppression
            supprimerTout();

            // Redirection vers la page principale après la suppression
            header("Location: classements.php");
            exit();
        }

        // Bouton Retour au formulaire
        echo "<br>";
        echo "<a href='formulaire.php'><button>Retour au formulaire</button></a>";

        // Bouton Supprimer tout
        echo "<br>";
        echo "<a href='supprimer.php'><button>Supprimer tout</button></a>";
        ?>

        <h2>Confirmer la suppression de toutes les données</h2>
            <form method="post">
                <p>Êtes-vous sûr de vouloir supprimer toutes les données de la base de données ? Cette action est irréversible.</p>
                <button type="submit" name="supprimer">Confirmer la suppression</button>
            </form>
        <style>
            button {
                color: #fff;
                background-color: #e74c3c;
                padding: 8px 16px;
                text-decoration: none;
                border-radius: 5px;
                transition: background-color 0.3s;
            }

            button:hover {
                background-color: #c0392b;
            }
        </style>

    </main>
</body>

</html>
