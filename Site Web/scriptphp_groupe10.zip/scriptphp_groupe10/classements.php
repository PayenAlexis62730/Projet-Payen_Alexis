<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style_classement.css" rel="stylesheet" />
    <title>Exploration de l'esport sur Rainbow Six Siege</title>
</head>

<body>
    <img class ="notre_logo" src="img/logo.png">
    <img class="logo_6" src="img/6OC_2022.png" alt="Logo" />

    <nav>
        <a href="acceuil.html">Accueil</a>
        <a href="explication.html">Avancement</a>
        <a href="carte.html"> Cartes </a>
        <a href="heros.html"> Héros </a>
        <a href="classements.html"> Classements </a>
        <a href="equipes.html"> Equipes </a>
        <a href="formulaire.php"> Votre tournoi  </a>
    </nav>

    <main>
        <?php include('classement.php'); ?> </br>

        <form action="traitement_class.php" method="post">
            <label for="numero">Choisissez un numéro pour voir les statistiques du match  :</label>
            <select name="numero" id="numero">
                <?php
                for ($i = 1; $i <= 7; $i++) {
                    echo "<option value='$i'>$i</option>";
                }
                ?>
            </select>
            <input type="submit" value="Afficher">
        </form>

</main>

    <footer>
        <p>Site créé par </p>
        <ul>
            <li> DUPUIS Brian | LELONG Thomas | MAZURIER Eve | PAYEN Alexis  </li>
            <li> <a href="mentions.html">Mentions légales</a> </li>
            <li> <a href="deconnexion.php" class="deconnexion-btn">Déconnexion</a> </li>
        </ul>
    </footer>

    <style>
        a{
            color: #fff; 
        }
        .deconnexion-btn {
            color: #fff; 
            background-color: #e74c3c; 
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s; 
        }
        
        .deconnexion-btn:hover {
            background-color: #c0392b;
        }
    </style>
</body>

</html>
