<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="style_heros.css" rel="stylesheet" />
    <title>Exploration de l'esport sur Rainbow Six Siege</title>
</head>

<body>
    <header>
        <img class ="notre_logo" src="img/logo.png">
        <img class="logo_6" src="img/6OC_2022.png" alt="Logo" />
    </header>

    <nav>
        <a href="acceuil.html">Accueil</a>
        <a href="explication.html">Avancement</a>
        <a href="carte.html"> Cartes </a>
        <a href="heros.php"> Héros </a>
        <a href="classements.php"> Classements </a>
        <a href="equipes.html"> Equipes </a>
        <a href="formulaire.php"> Votre choix  </a>
    </nav>

    <main>

        <section>
            <h2> Voici la liste de toutes les héros disponibles : </h2>
        </section>
        
        <section>
            <div class="heros">
                <img src="img/persos/1.png" />
                <img src="img/persos/2.png" />
                <img src="img/persos/3.png" />
                <img src="img/persos/4.png" />
                <img src="img/persos/5.png" />
                <img src="img/persos/6.png" />
                <img src="img/persos/7.png" />
                <img src="img/persos/8.png" />
                <img src="img/persos/9.png" />
                <img src="img/persos/10.png" />
                <img src="img/persos/11.png" />
                <img src="img/persos/12.png" />
                <img src="img/persos/13.png" />
                <img src="img/persos/14.png" />
                <img src="img/persos/15.png" />
                <img src="img/persos/16.png" />
                <img src="img/persos/17.png" />
            </div>

            <section>
                <h2> Voici la liste de toutes les armes et gadgets disponibles : </h2>
            </section>

            <h3> Equipements </h3>
            <?php include ('armes.php')?>

            <h3> Gadgets </h3>
            <?php include ('gadget.php')?>
            
            <style>
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-top: 20px;
                    }

                    th, td {
                        padding: 12px;
                        text-align: left;
                        border: 1px solid #ddd;
                    }

                    th {
                        background-color: #f2f2f2;
                    }

                    tr:hover {
                        background-color: #f5f5f5;
                    }
                </style>

        
        
    
    </main>

    <footer>
        <p>Site créé par </p>
        <ul>
            <li> DUPUIS Brian | LELONG Thomas | MAZURIER Eve | PAYEN Alexis  </li>
            <li> <a href="mentions.html">Mentions légales</a> </li>
            <li> <a href="deconnexion.php" class="deconnexion-btn">Déconnexion</a> </li>
        </ul>
    </footer>

    <style>
        a{
            color: #fff;   
        }
        .deconnexion-btn {
            color: #fff; 
            background-color: #e74c3c; 
            padding: 8px 16px; 
            text-decoration: none; 
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        
        .deconnexion-btn:hover {
            background-color: #c0392b; 
        }
    </style>
</body>

</html>
