<?php
$host = 'database';
$port = '5432';
$dbname = 'sae-esport';
$user = 'sae-esport';
$password = 'hkgvMekMlp2U'; // Mettez votre mot de passe réel ici

try {
    $pdo = new PDO("pgsql:host=$host;port=$port;dbname=$dbname;user=$user;password=$password");

    // Requête SQL avec jointure pour récupérer les données du classement
    $sql = "SELECT appartenance , nom_gadget FROM gadget";

    $result = $pdo->query($sql);

    // Vérifier si la requête a été exécutée correctement
    if ($result !== false) {
        // Vérifier s'il y a des résultats
        if ($result->rowCount() > 0) {
            // Afficher les résultats dans un tableau
            echo "<table border='1'>";
            echo "<th>Appartenance </th><th>Nom Gadget</th></tr>";

            // Boucler à travers les résultats et afficher chaque ligne
            while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr><td>" . $row["appartenance"] . "</td><td>" . $row["nom_gadget"] . "</td>";
            }

            echo "</table>";


        } else {
            echo "Aucun résultat trouvé.";
        }
    } else {
        echo "Erreur dans la requête SQL.";
    }
} catch (PDOException $e) {
    echo "Erreur de connexion : " . $e->getMessage();
}
?>
