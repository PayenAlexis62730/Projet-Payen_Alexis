<?php
session_start();

if (isset($_SESSION['utilisateur_id'])) {
    header('Location: tableau_de_bord.php');  // Redirigez vers la page d'accueil après l'authentification réussie
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nom_utilisateur = $_POST['nom_utilisateur'];
    $mot_de_passe = $_POST['mot_de_passe'];

    // Vérification des identifiants prédéfinis administrateur et pour Monsieur Capitaine 
    if (($nom_utilisateur === 'admin' && $mot_de_passe === 'admin') ||
        ($nom_utilisateur === 'm.capitaine' && $mot_de_passe === 'saeesportr6')) {
        $_SESSION['utilisateur_id'] = 1;  
        header('Location: tableau_de_bord.php');
        exit();
    } else {
        $erreur = 'Nom d\'utilisateur ou mot de passe incorrect';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page de Connexion</title>
</head>
<body>
    <?php if (isset($erreur)) : ?>
        <p style="color: red;"><?php echo $erreur; ?></p>
    <?php endif; ?>
    <form method="post" action="">
        <label for="nom_utilisateur">Nom d'utilisateur:</label>
        <input type="text" id="nom_utilisateur" name="nom_utilisateur" required><br>
        <label for="mot_de_passe">Mot de passe:</label>
        <input type="password" id="mot_de_passe" name="mot_de_passe" required><br>
        <button type="submit">Se connecter</button>
    </form>

    <style>
    body {
        font-family: 'Arial', sans-serif;
        font-size: 16px;
        margin: 0;
        padding: 0;
        background: url('img/r6.jpg') center/cover no-repeat fixed;
        background-color: rgba(250, 250, 250, 0.7);
        color: #333;
    }

    h2 {
        text-align: center;
        color: black;
    }

    form {
        max-width: 400px;
        margin: 20px auto;
        padding: 20px;
        background-color: #3498db;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 15px;
        color: #fff;
    }

    label {
        display: block;
        margin-bottom: 8px;
        color: #fff;
    }

    input {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    button {
        background-color: #2c3e50;
        color: #fff;
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    button:hover {
        background-color: #34495e;
    }

    p.error {
        color: red;
        text-align: center;
    }
    </style>

</body>
</html>
