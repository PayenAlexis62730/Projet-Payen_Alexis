insert into avoir_participer VALUES (1, 1, NULL, NULL, 3);
insert into avoir_participer VALUES (1, 2, NULL, NULL, 0);
insert into avoir_participer VALUES (2, 3, NULL, NULL, 3);
insert into avoir_participer VALUES (2, 4, NULL, NULL, 0);
insert into avoir_participer VALUES (3, 5, NULL, NULL, 3);
insert into avoir_participer VALUES (3, 6, NULL, NULL, 0);
insert into avoir_participer VALUES (4, 7, NULL, NULL, 3);
insert into avoir_participer VALUES (4, 8, NULL, NULL, 0);
insert into avoir_participer VALUES (5, 1, NULL, NULL, 3);
insert into avoir_participer VALUES (5, 3, NULL, NULL, 0);
insert into avoir_participer VALUES (6, 2, NULL, NULL, 3);
insert into avoir_participer VALUES (6, 4, NULL, NULL, 0);


