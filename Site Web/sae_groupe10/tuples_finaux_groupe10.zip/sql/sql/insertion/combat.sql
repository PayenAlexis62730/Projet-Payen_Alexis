/*Tuples pour la table combat 
UN combat se déroule en différentes catégories , est composé de 2 équipes et évidemment un gagnant avec le score associé
*/
CREATE TABLE combat (
    id_combat INT PRIMARY KEY,
    qualification VARCHAR(255),
    date_combat DATE,
    equipeA VARCHAR(255),
    equipeB VARCHAR(255),
    equipe_gagnante VARCHAR(255),
    id_carte INT,
    score VARCHAR(255),
    FOREIGN KEY (equipe_gagnante) REFERENCES equipe(id_equipe),
    FOREIGN KEY (id_carte) REFERENCES carte(id_carte)
);

SET datestyle = 'ISO, DMY';
INSERT INTO combat VALUES(1,'1/4 finale', '22-06-2022', 'Wolves Esports' , 'Deathrow Academy' ,8 ,'0-2', 8);
INSERT INTO combat VALUES(2,'1/4 finale', '22-06-2022', 'Maestria' , 'Deathrow' ,3 ,'0-2',3);
INSERT INTO combat VALUES(3,'1/4 finale', '22-06-2022', 'Exalty' , 'MalaGanxts' ,5 ,'0-2',7);
INSERT INTO combat VALUES(4,'1/4 finale', '22-06-2022', 'ACEND' , 'WAFWAF' ,2 ,'2-0',11);
INSERT INTO combat VALUES(5,'1/2 finale', '24-06-2022', 'Deathrow Academy' , 'Deathrow' ,3 ,'0-2',8);
INSERT INTO combat VALUES(6,'1/2 finale', '24-06-2022','MalaGanxts' , 'ACEND' ,2 ,'0-2',1);
INSERT INTO combat VALUES(7,'finale', '26-06-2022', 'Deathrow' , 'ACEND' ,2 ,'1-2',5);