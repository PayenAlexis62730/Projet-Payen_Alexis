--Format d'insertion (id_equipe , id_joueur, id-combat, date_combat, id_hero_kill_mort)

--Combat 1--

-- Équipe Wolves Esport
INSERT INTO avoir_joue VALUES (1,1, 1, '22/06/2022', 2, 5, 5);
INSERT INTO avoir_joue VALUES (1,2, 1, '22/06/2022', 4, 3, 5);
INSERT INTO avoir_joue VALUES (1,3, 1, '22/06/2022', 6, 2, 4);
INSERT INTO avoir_joue VALUES (1,4, 1, '22/06/2022', 7, 8, 3);
INSERT INTO avoir_joue VALUES (1,5, 1, '22/06/2022', 12, 0, 5);

-- Deathrow Academy
INSERT INTO avoir_joue VALUES (8,36, 1, '22/06/2022', 70, 11, 5);
INSERT INTO avoir_joue VALUES (8,37, 1, '22/06/2022', 61, 5, 1);
INSERT INTO avoir_joue VALUES (8,38, 1, '22/06/2022', 41, 3, 5);
INSERT INTO avoir_joue VALUES (8,39, 1, '22/06/2022', 44, 3, 4);
INSERT INTO avoir_joue VALUES (8,40, 1, '22/06/2022', 29, 0, 3);

--Combat 2--

-- Maestria 
INSERT INTO avoir_joue VALUES (6,26, 2, '22/06/2022', 68, 0, 5);
INSERT INTO avoir_joue VALUES (6,27, 2, '22/06/2022', 49, 1, 5);
INSERT INTO avoir_joue VALUES (6,28, 2, '22/06/2022', 46, 2, 4);
INSERT INTO avoir_joue VALUES (6,29, 2, '22/06/2022', 58, 2, 4);
INSERT INTO avoir_joue VALUES (6,30, 2, '22/06/2022', 59, 1, 5);

-- Deathrow
INSERT INTO avoir_joue VALUES (3,11, 2, '22/06/2022', 70, 4, 0);
INSERT INTO avoir_joue VALUES (3,12, 2, '22/06/2022', 61, 13, 1);
INSERT INTO avoir_joue VALUES (3,13, 2, '22/06/2022', 41, 2, 1);
INSERT INTO avoir_joue VALUES (3,14, 2, '22/06/2022', 44, 3, 2);
INSERT INTO avoir_joue VALUES (3,15, 2, '22/06/2022', 29, 1, 2);

--Combat 3--

-- Exalty
INSERT INTO avoir_joue VALUES (4,16, 3, '22/06/2022', 27, 4, 5);
INSERT INTO avoir_joue VALUES (4,17, 3, '22/06/2022', 15, 5, 5);
INSERT INTO avoir_joue VALUES (4,18, 3, '22/06/2022', 12, 3, 4);
INSERT INTO avoir_joue VALUES (4,19, 3, '22/06/2022', 39, 3, 4);
INSERT INTO avoir_joue VALUES (4,20, 3, '22/06/2022', 4, 6, 3);

-- MalaGanxts
INSERT INTO avoir_joue VALUES (5,21, 3, '22/06/2022', 70, 6, 5);
INSERT INTO avoir_joue VALUES (5,22, 3, '22/06/2022', 61, 6, 4);
INSERT INTO avoir_joue VALUES (5,23, 3, '22/06/2022', 41, 4, 4);
INSERT INTO avoir_joue VALUES (5,24, 3, '22/06/2022', 44, 2, 3);
INSERT INTO avoir_joue VALUES (5,25, 3, '22/06/2022', 29, 3, 5);

--Combat 4--

-- ACEND
INSERT INTO avoir_joue VALUES (2,6, 4, '22/06/2022', 12, 8, 2);
INSERT INTO avoir_joue VALUES (2,7, 4, '22/06/2022', 23, 8, 2);
INSERT INTO avoir_joue VALUES (2,8, 4, '22/06/2022', 52, 2, 4);
INSERT INTO avoir_joue VALUES (2,9, 4, '22/06/2022', 58, 2, 2);
INSERT INTO avoir_joue VALUES (2,10, 4, '22/06/2022', 59, 5, 3);

-- WAFWAF
INSERT INTO avoir_joue VALUES (7,31, 4, '22/06/2022', 70, 4, 5);
INSERT INTO avoir_joue VALUES (7,32, 4, '22/06/2022', 9, 2, 5);
INSERT INTO avoir_joue VALUES (7,33, 4, '22/06/2022', 48, 3, 5);
INSERT INTO avoir_joue VALUES (7,34, 4, '22/06/2022', 25, 3, 5);
INSERT INTO avoir_joue VALUES (7,35, 4, '22/06/2022', 50, 1, 5);

--Combat 5--

-- Deathrow Academy
INSERT INTO avoir_joue VALUES (8,36, 5, '27/06/2022', 26, 5, 5);
INSERT INTO avoir_joue VALUES (8,37, 5, '27/06/2022', 15, 0, 5);
INSERT INTO avoir_joue VALUES (8,38, 5, '27/06/2022', 6, 1, 5);
INSERT INTO avoir_joue VALUES (8,39, 5, '27/06/2022', 55, 3, 5);
INSERT INTO avoir_joue VALUES (8,40, 5, '27/06/2022', 68, 0, 5);

-- Deathrow
INSERT INTO avoir_joue VALUES (3,11, 5, '27/06/2022', 70, 8, 2);
INSERT INTO avoir_joue VALUES (3,12, 5, '27/06/2022', 45, 5, 4);
INSERT INTO avoir_joue VALUES (3,13, 5, '27/06/2022', 44, 5, 1);
INSERT INTO avoir_joue VALUES (3,14, 5, '27/06/2022', 41, 5, 1);
INSERT INTO avoir_joue VALUES (3,15, 5, '27/06/2022', 13, 2, 1);

--Combat 6--

--MalaGanxt--
INSERT INTO avoir_joue VALUES (5,21, 6, '28/06/2022', 15, 6, 5);
INSERT INTO avoir_joue VALUES (5,22, 6, '28/06/2022', 34, 4, 4);
INSERT INTO avoir_joue VALUES (5,23, 6, '28/06/2022', 33, 4, 3);
INSERT INTO avoir_joue VALUES (5,24, 6, '28/06/2022', 58, 3, 5);
INSERT INTO avoir_joue VALUES (5,25, 6, '28/06/2022', 2, 2, 5);

--ACEND--
INSERT INTO avoir_joue VALUES (2,6, 4, '28/06/2022', 70, 14, 4);
INSERT INTO avoir_joue VALUES (2,7, 4, '28/06/2022', 69, 2, 5);
INSERT INTO avoir_joue VALUES (2,8, 4, '28/06/2022', 64, 6, 4);
INSERT INTO avoir_joue VALUES (2,9, 4, '28/06/2022', 63, 0, 3);
INSERT INTO avoir_joue VALUES (2,10, 4, '28/06/2022', 1, 0, 3);


--Combat 7--

-- Deathrow
INSERT INTO avoir_joue VALUES (3,11, 5, '02/07/2022', 12, 7, 5);
INSERT INTO avoir_joue VALUES (3,12, 5, '02/07/2022', 27, 3, 4);
INSERT INTO avoir_joue VALUES (3,13, 5, '02/07/2022', 43, 3, 4);
INSERT INTO avoir_joue VALUES (3,14, 5, '02/07/2022', 36, 2, 4);
INSERT INTO avoir_joue VALUES (3,15, 5, '02/07/2022', 54, 6, 4);

--ACEND--
INSERT INTO avoir_joue VALUES (2,6, 4, '02/07/2022', 69, 5, 4);
INSERT INTO avoir_joue VALUES (2,7, 4, '02/07/2022', 64, 4, 5);
INSERT INTO avoir_joue VALUES (2,8, 4, '02/07/2022', 35, 6, 4);
INSERT INTO avoir_joue VALUES (2,9, 4, '02/07/2022', 22, 2, 4);
INSERT INTO avoir_joue VALUES (2,10, 4, '02/07/2022', 19, 4, 4);


CREATE TABLE avoir_joue (
    id_equipe INT , 
    id_joueur INT,
    id_combat INT,
    date_combat date,
    id_heros INT,
    kill_joueur INT,
    mort_joueur INT,
    PRIMARY KEY (id_equipe , id_joueur, id_combat, date_combat),
    FOREIGN KEY (id_combat) REFERENCES combat(id_combat),
    FOREIGN KEY (id_joueur) REFERENCES joueur(id_joueur),
    FOREIGN KEY (id_heros) REFERENCES heros(id_heros)
);