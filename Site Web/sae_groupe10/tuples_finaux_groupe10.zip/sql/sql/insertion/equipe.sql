/* Tuples de la table equipe :
Dans ce tournoi il y a 8 equipes , dans cette table on aura l'id de l'équipe le nom de cette équipe et de qui elle sera composée:
    - il y a 5 joueurs 
    - de 1 à 2 coatchs ou parfois 0
*/


INSERT INTO equipe VALUES (1, 'Wolves Esports');
INSERT INTO equipe VALUES (2, 'ACEND');
INSERT INTO equipe VALUES (3, 'DeathroW');
INSERT INTO equipe VALUES (4, 'Exalty');
INSERT INTO equipe VALUES (5, 'MalaGanxst');
INSERT INTO equipe VALUES (6, 'Maestria');
INSERT INTO equipe VALUES (7, 'WAFWAF');
INSERT INTO equipe VALUES (8, 'deathroW academy');

