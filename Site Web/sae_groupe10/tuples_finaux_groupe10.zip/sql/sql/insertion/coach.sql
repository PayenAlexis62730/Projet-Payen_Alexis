--Wolves Esports
INSERT INTO coach VALUES (1, 'Laurie', 'Lagier', 'Lyloun', 'FRANCE');
INSERT INTO coach VALUES (2, 'Louis', 'Bureau', 'Helbee', 'CANNADA');

--ACEND
INSERT INTO coach VALUES (3, NULL, NULL, 'Akhdar', 'FRANCE');

--DeathroW
INSERT INTO coach VALUES (4, 'Walid', 'Violleau', 'Hyrzuka', 'FRANCE');
INSERT INTO coach VALUES (5, 'Antoine', 'Dupuy', 'Yntensity', 'FRANCE');

--Exalty
INSERT INTO coach VALUES (6, NULL, NULL, 'pulgaz', 'FRANCE');

--MalaGanxst

--Maestria
INSERT INTO coach VALUES (7, 'Maxime', 'Nourrigat', 'Bolt', 'FRANCE');

--WAFWAF

--DeathroW Academy
INSERT INTO coach VALUES (8, 'Benjamin', 'Bigot', 'JurBy', 'FRANCE');
INSERT INTO coach VALUES (9, 'Yohann', 'Guillaume', 'Legend', 'FRANCE');