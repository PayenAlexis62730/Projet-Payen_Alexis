---------------------------------------
INSERT INTO appartenir VALUES (1,1);
INSERT INTO appartenir VALUES (2,1);
INSERT INTO appartenir VALUES (3,1);
INSERT INTO appartenir VALUES (4,1);
INSERT INTO appartenir VALUES (5,1);
----------------------------------------
INSERT INTO appartenir VALUES (6,2);
INSERT INTO appartenir VALUES (7,2);
INSERT INTO appartenir VALUES (8,2);
INSERT INTO appartenir VALUES (9,2);
INSERT INTO appartenir VALUES (10,2);
-----------------------------------------
INSERT INTO appartenir VALUES (11,3);
INSERT INTO appartenir VALUES (12,3);
INSERT INTO appartenir VALUES (13,3);
INSERT INTO appartenir VALUES (14,3);
INSERT INTO appartenir VALUES (15,3);
----------------------------------------
INSERT INTO appartenir VALUES (16,4);
INSERT INTO appartenir VALUES (17,4);
INSERT INTO appartenir VALUES (18,4);
INSERT INTO appartenir VALUES (19,4);
INSERT INTO appartenir VALUES (20,4);
---------------------------------------
INSERT INTO appartenir VALUES (21,5);
INSERT INTO appartenir VALUES (22,5);
INSERT INTO appartenir VALUES (23,5);
INSERT INTO appartenir VALUES (24,5);
INSERT INTO appartenir VALUES (25,5);
--------------------------------------
INSERT INTO appartenir VALUES (26,6);
INSERT INTO appartenir VALUES (27,6);
INSERT INTO appartenir VALUES (28,6);
INSERT INTO appartenir VALUES (29,6);
INSERT INTO appartenir VALUES (30,6);
---------------------------------------
INSERT INTO appartenir VALUES (31,7);
INSERT INTO appartenir VALUES (32,7);
INSERT INTO appartenir VALUES (33,7);
INSERT INTO appartenir VALUES (34,7);
INSERT INTO appartenir VALUES (35,7);
---------------------------------------
INSERT INTO appartenir VALUES (36,8);
INSERT INTO appartenir VALUES (37,8);
INSERT INTO appartenir VALUES (38,8);
INSERT INTO appartenir VALUES (39,8);
INSERT INTO appartenir VALUES (40,8);