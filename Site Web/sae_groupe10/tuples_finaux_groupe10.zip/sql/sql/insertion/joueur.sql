--Wolves Esports
INSERT INTO joueur VALUES (1, 'bastien', 'dulac', 'biBoo', 'FRANCE');
INSERT INTO joueur VALUES (2, 'Valentin', 'Liradelfo', 'risze', 'BELGIQUE');
INSERT INTO joueur VALUES (3, 'Nicolas', 'Rimbaud', 'P4', 'FRANCE');
INSERT INTO joueur VALUES (4, 'Axel', 'Freisberg', 'Shiinka', 'FRANCE');
INSERT INTO joueur VALUES (5, 'Yanis', 'Dahmani', 'Mowwwgli', 'FRANCE');

--ACEND
INSERT INTO joueur VALUES (6, 'Julian', 'Blin', 'ENEMY,', 'FRANCE');
INSERT INTO joueur VALUES (7, 'Jean', 'Prudenti', 'RevaN', 'FRANCE');
INSERT INTO joueur VALUES (8, 'Medhi', 'Marty', 'Kaktus', 'FRANCE');
INSERT INTO joueur VALUES (9, 'Jimmy', 'Vojtasik', 'DEADSHT', 'SUISSE');
INSERT INTO joueur VALUES (10, 'Hugo', 'Kneip', 'Ra1kos', 'PAYS-BAS');

--DeathroW
INSERT INTO joueur VALUES (11, 'Brice', 'Mahmoud', 'Shoukri', 'FRANCE');
INSERT INTO joueur VALUES (12, 'Théo', 'Leguay', 'Frenchy', 'FRANCE');
INSERT INTO joueur VALUES (13, 'Goran', 'Kwiatek', 'Gorank', 'BELGIQUE');
INSERT INTO joueur VALUES (14, 'Victor', 'Mamont', 'Prime', 'FRANCE');
INSERT INTO joueur VALUES (15, 'Swazi', 'Figueiredo', 'Swaz', 'PORTUGALE');

--Exalty
INSERT INTO joueur VALUES (16, NULL, NULL, 'Frozxn', 'FRANCE');
INSERT INTO joueur VALUES (17, NULL, NULL, 'byBMS', 'FRANCE');
INSERT INTO joueur VALUES (18, NULL, NULL, 'Zydenn', 'FRANCE');
INSERT INTO joueur VALUES (19, NULL, NULL, 'Ravage', 'FRANCE');
INSERT INTO joueur VALUES (20, NULL, NULL, 'Fire', 'FRANCE');

--MalaGanxst
INSERT INTO joueur VALUES (21, NULL, NULL, 'SkyZs', 'FRANCE');
INSERT INTO joueur VALUES (22, 'Jawad', 'Oudghiri', 'Linkoo', 'FRANCE');
INSERT INTO joueur VALUES (23, NULL, NULL, 'Asa', 'FRANCE');
INSERT INTO joueur VALUES (24, NULL, NULL, 'Nayqo', 'FRANCE');
INSERT INTO joueur VALUES (25, NULL, NULL, 'itsdreoz', 'FRANCE');

--Maestria
INSERT INTO joueur VALUES (26, NULL, NULL, 'Paanda', 'FRANCE');
INSERT INTO joueur VALUES (27, NULL, NULL, 'KingADN', 'FRANCE');
INSERT INTO joueur VALUES (28, NULL, NULL, 'ToroQ', 'FRANCE');
INSERT INTO joueur VALUES (29, 'Kilyam', 'Thomas', 'Steely', 'FRANCE');
INSERT INTO joueur VALUES (30, NULL, NULL, 'Etoiles', 'FRANCE');

--WAFWAF
INSERT INTO joueur VALUES (31, NULL, NULL, 'PingWIN', 'POLONE');
INSERT INTO joueur VALUES (32, NULL, NULL, 'Beuster', 'FRANCE');
INSERT INTO joueur VALUES (33, NULL, NULL, 'Volt', 'FRANCE');
INSERT INTO joueur VALUES (34, NULL, NULL, 'Fiazko', 'FRANCE');
INSERT INTO joueur VALUES (35, NULL, NULL, 'Nztrox', 'FRANCE');

--DeathroW Academy
INSERT INTO joueur VALUES (36, 'Mathis', 'Lecorvaisier', 'Cryz', 'FRANCE');
INSERT INTO joueur VALUES (37, 'Antoine', 'Blandin', 'Deezay', 'FRANCE');
INSERT INTO joueur VALUES (38, 'Nolhan', 'Grandjean', 'Heaven', 'FRANCE');
INSERT INTO joueur VALUES (39, 'Enzo', 'Journo', 'Mikaa', 'FRANCE');
INSERT INTO joueur VALUES (40, 'Lucas', 'Le Bihan', 'YaDDle', 'FRANCE');