/* Tuples de la table récompenses :
A la fin du tournoi les 4 premiers du classement remportent des cashprices 
Les prix étant :
        - premier : 10 000euros 
        - deuxième : 5 000 euros 
        - troisième : 3 000 euros 
        - quatrième : 2 000 euros
*/

INSERT INTO recompenses VALUES(1, 10000);
INSERT INTO recompenses VALUES(2, 5000);
INSERT INTO recompenses VALUES(3, 3000);
INSERT INTO recompenses VALUES(4, 2000);
