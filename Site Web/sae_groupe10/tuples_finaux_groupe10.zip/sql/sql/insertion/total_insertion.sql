-- Table joueur
INSERT INTO joueur VALUES (1, 'bastien', 'dulac', 'biBoo', 'FRANCE');
INSERT INTO joueur VALUES (2, 'Valentin', 'Liradelfo', 'risze', 'BELGIQUE');
INSERT INTO joueur VALUES (3, 'Nicolas', 'Rimbaud', 'P4', 'FRANCE');
INSERT INTO joueur VALUES (4, 'Axel', 'Freisberg', 'Shiinka', 'FRANCE');
INSERT INTO joueur VALUES (5, 'Yanis', 'Dahmani', 'Mowwwgli', 'FRANCE');
INSERT INTO joueur VALUES (6, 'Julian', 'Blin', 'ENEMY,', 'FRANCE');
INSERT INTO joueur VALUES (7, 'Jean', 'Prudenti', 'RevaN', 'FRANCE');
INSERT INTO joueur VALUES (8, 'Medhi', 'Marty', 'Kaktus', 'FRANCE');
INSERT INTO joueur VALUES (9, 'Jimmy', 'Vojtasik', 'DEADSHT', 'SUISSE');
INSERT INTO joueur VALUES (10, 'Hugo', 'Kneip', 'Ra1kos', 'PAYS-BAS');
INSERT INTO joueur VALUES (11, 'Brice', 'Mahmoud', 'Shoukri', 'FRANCE');
INSERT INTO joueur VALUES (12, 'Théo', 'Leguay', 'Frenchy', 'FRANCE');
INSERT INTO joueur VALUES (13, 'Goran', 'Kwiatek', 'Gorank', 'BELGIQUE');
INSERT INTO joueur VALUES (14, 'Victor', 'Mamont', 'Prime', 'FRANCE');
INSERT INTO joueur VALUES (15, 'Swazi', 'Figueiredo', 'Swaz', 'PORTUGALE');
INSERT INTO joueur VALUES (16, NULL, NULL, 'Frozxn', 'FRANCE');
INSERT INTO joueur VALUES (17, NULL, NULL, 'byBMS', 'FRANCE');
INSERT INTO joueur VALUES (18, NULL, NULL, 'Zydenn', 'FRANCE');
INSERT INTO joueur VALUES (19, NULL, NULL, 'Ravage', 'FRANCE');
INSERT INTO joueur VALUES (20, NULL, NULL, 'Fire', 'FRANCE');
INSERT INTO joueur VALUES (21, NULL, NULL, 'SkyZs', 'FRANCE');
INSERT INTO joueur VALUES (22, 'Jawad', 'Oudghiri', 'Linkoo', 'FRANCE');
INSERT INTO joueur VALUES (23, NULL, NULL, 'Asa', 'FRANCE');
INSERT INTO joueur VALUES (24, NULL, NULL, 'Nayqo', 'FRANCE');
INSERT INTO joueur VALUES (25, NULL, NULL, 'itsdreoz', 'FRANCE');
INSERT INTO joueur VALUES (26, NULL, NULL, 'Paanda', 'FRANCE');
INSERT INTO joueur VALUES (27, NULL, NULL, 'KingADN', 'FRANCE');
INSERT INTO joueur VALUES (28, NULL, NULL, 'ToroQ', 'FRANCE');
INSERT INTO joueur VALUES (29, 'Kilyam', 'Thomas', 'Steely', 'FRANCE');
INSERT INTO joueur VALUES (30, NULL, NULL, 'Etoiles', 'FRANCE');
INSERT INTO joueur VALUES (31, NULL, NULL, 'PingWIN', 'POLONE');
INSERT INTO joueur VALUES (32, NULL, NULL, 'Beuster', 'FRANCE');
INSERT INTO joueur VALUES (33, NULL, NULL, 'Volt', 'FRANCE');
INSERT INTO joueur VALUES (34, NULL, NULL, 'Fiazko', 'FRANCE');
INSERT INTO joueur VALUES (35, NULL, NULL, 'Nztrox', 'FRANCE');
INSERT INTO joueur VALUES (36, 'Mathis', 'Lecorvaisier', 'Cryz', 'FRANCE');
INSERT INTO joueur VALUES (37, 'Antoine', 'Blandin', 'Deezay', 'FRANCE');
INSERT INTO joueur VALUES (38, 'Nolhan', 'Grandjean', 'Heaven', 'FRANCE');
INSERT INTO joueur VALUES (39, 'Enzo', 'Journo', 'Mikaa', 'FRANCE');
INSERT INTO joueur VALUES (40, 'Lucas', 'Le Bihan', 'YaDDle', 'FRANCE');

-- Table coach 
INSERT INTO coach VALUES (1, 'Laurie', 'Lagier', 'Lyloun', 'FRANCE');
INSERT INTO coach VALUES (2, 'Louis', 'Bureau', 'Helbee', 'CANNADA');
INSERT INTO coach VALUES (3, NULL, NULL, 'Akhdar', 'FRANCE');
INSERT INTO coach VALUES (4, 'Walid', 'Violleau', 'Hyrzuka', 'FRANCE');
INSERT INTO coach VALUES (5, 'Antoine', 'Dupuy', 'Yntensity', 'FRANCE');
INSERT INTO coach VALUES (6, NULL, NULL, 'pulgaz', 'FRANCE');
INSERT INTO coach VALUES (7, 'Maxime', 'Nourrigat', 'Bolt', 'FRANCE');
INSERT INTO coach VALUES (8, 'Benjamin', 'Bigot', 'JurBy', 'FRANCE');
INSERT INTO coach VALUES (9, 'Yohann', 'Guillaume', 'Legend', 'FRANCE');

-- Table equipe 
INSERT INTO equipe VALUES (1, 'Wolves Esports');
INSERT INTO equipe VALUES (2, 'ACEND');
INSERT INTO equipe VALUES (3, 'DeathroW');
INSERT INTO equipe VALUES (4, 'Exalty');
INSERT INTO equipe VALUES (5, 'MalaGanxst');
INSERT INTO equipe VALUES (6, 'Maestria');
INSERT INTO equipe VALUES (7, 'WAFWAF');
INSERT INTO equipe VALUES (8, 'deathroW academy');

-- Table appartenir 
INSERT INTO appartenir VALUES (1,1);
INSERT INTO appartenir VALUES (2,1);
INSERT INTO appartenir VALUES (3,1);
INSERT INTO appartenir VALUES (4,1);
INSERT INTO appartenir VALUES (5,1);
INSERT INTO appartenir VALUES (6,2);
INSERT INTO appartenir VALUES (7,2);
INSERT INTO appartenir VALUES (8,2);
INSERT INTO appartenir VALUES (9,2);
INSERT INTO appartenir VALUES (10,2);
INSERT INTO appartenir VALUES (11,3);
INSERT INTO appartenir VALUES (12,3);
INSERT INTO appartenir VALUES (13,3);
INSERT INTO appartenir VALUES (14,3);
INSERT INTO appartenir VALUES (15,3);
INSERT INTO appartenir VALUES (16,4);
INSERT INTO appartenir VALUES (17,4);
INSERT INTO appartenir VALUES (18,4);
INSERT INTO appartenir VALUES (19,4);
INSERT INTO appartenir VALUES (20,4);
INSERT INTO appartenir VALUES (21,5);
INSERT INTO appartenir VALUES (22,5);
INSERT INTO appartenir VALUES (23,5);
INSERT INTO appartenir VALUES (24,5);
INSERT INTO appartenir VALUES (25,5);
INSERT INTO appartenir VALUES (26,6);
INSERT INTO appartenir VALUES (27,6);
INSERT INTO appartenir VALUES (28,6);
INSERT INTO appartenir VALUES (29,6);
INSERT INTO appartenir VALUES (30,6);
INSERT INTO appartenir VALUES (31,7);
INSERT INTO appartenir VALUES (32,7);
INSERT INTO appartenir VALUES (33,7);
INSERT INTO appartenir VALUES (34,7);
INSERT INTO appartenir VALUES (35,7);
INSERT INTO appartenir VALUES (36,8);
INSERT INTO appartenir VALUES (37,8);
INSERT INTO appartenir VALUES (38,8);
INSERT INTO appartenir VALUES (39,8);
INSERT INTO appartenir VALUES (40,8);

--Table diriger
INSERT INTO diriger VALUES (1,1);
INSERT INTO diriger VALUES (2,1);
INSERT INTO diriger VALUES (3,2);
INSERT INTO diriger VALUES (4,3);
INSERT INTO diriger VALUES (5,3);
INSERT INTO diriger VALUES (6,4);
INSERT INTO diriger VALUES (7,6);
INSERT INTO diriger VALUES (8,8);
INSERT INTO diriger VALUES (9,8);

-- Table heros 
INSERT INTO heros (id_heros, nom_heros, affiliation, capacite, sante, vitesse, nationalite)
VALUES
    (1, 'tubarao', 'defenseur', 'capsule d azote', 2, 2, 'portugal'),
    (2, 'ram', 'assaillant', 'breche automatique bateau tortue', 3, 1, 'coree du sud'),
    (3, 'fenrir', 'defenseur', 'mine d effroi f-natt', 2, 2, 'suede'),
    (4, 'brava', 'assaillant', 'drone kludge', 1, 3, 'bresil'),
    (5, 'solis', 'defenseur', 'capteur electrique spec-io', 2, 2, 'colombie'),
    (6, 'grim', 'assaillant', 'lanceurs de ruches kawan', 1, 3, 'singapour'),
    (7, 'sens', 'assaillant', 'système de projection R.O.U', 1, 3, 'belgique'),
    (8, 'azami', 'defenseur', 'barriere kiba', 2, 2, 'japon'),
    (9, 'thorn', 'defenseur', 'rasopulseur', 2, 2, 'irlande'),
    (10, 'osa', 'assaillant', 'bouclier transparent talon-8', 3, 1, 'croatie'),
    (11, 'thunderbird', 'defenseur', 'station kona', 2, 2, 'usa'),
    (12, 'flores', 'assaillant', 'charge rce-ratero', 2, 2, 'argentine'),
    (13, 'aruni', 'defenseur', 'portail surya', 3, 1, 'thailande'),
    (14, 'zero', 'assaillant', 'lanceur argus', 1, 3, 'usa'),
    (15, 'ace', 'assaillant', 'aqua-sapeur s.e.l.m.a', 2, 2, 'norvege'),
    (16, 'melusi', 'defenseur', 'defense sonique banshee', 3, 1, 'afrique du sud'),
    (17, 'oryx', 'defenseur', 'remah dash', 2, 2, 'jordanie'),
    (18, 'iana', 'assaillant', 'gemini replicator', 2, 2, 'pays-bas'),
    (19, 'wamai', 'defenseur', 'systeme mag-net', 2, 2, 'kenya'),
    (20, 'kali', 'assaillant', 'lance explosive lv', 2, 2, 'inde'),
    (21, 'amaru', 'assaillant', 'crochet garra', 2, 2, 'perou'),
    (22, 'goyo', 'defenseur', 'bombe toxic volcan', 2, 2, 'mexique'),
    (23, 'nokk', 'assaillant', 'reduction de presence hel', 2, 2, 'null'),
    (24, 'warden', 'defenseur', 'lunette intelligente-regard', 2, 2, 'usa'),
    (25, 'mozzie', 'defenseur', 'lance-parasite', 2, 2, 'australie'),
    (26, 'gridlock', 'assaillant', 'dards track', 3, 1, 'australie'),
    (27, 'nomad', 'assaillant', 'lance airjab', 2, 2, 'maroc'),
    (28, 'kaid', 'defenseur', 'electrogriffe rtila', 3, 1, 'maroc'),
    (29, 'clash', 'defenseur', 'bouclier aee', 3, 1, 'angleterre'),
    (30, 'maverick', 'assaillant', 'chalumeau d infiltration', 1, 3, 'usa'),
    (31, 'maestro', 'defenseur', 'evil eye', 3, 1, 'italie'),
    (32, 'alibi', 'defenseur', 'prisme', 1, 3, 'libye'),
    (33, 'lion', 'assaillant', 'ee-one-d', 2, 2, 'france'),
    (34, 'finka', 'assaillant', 'shoot adrenaline', 2, 2, 'russie'),
    (35, 'vigil', 'defenseur', 'erc-7', 1, 3, 'null'),
    (36, 'dokkaebi', 'assaillant', 'bombe logique', 1, 3, 'coree du sud'),
    (37, 'zofia', 'assaillant', 'ks79 lifeline', 3, 1, 'pologne'),
    (38, 'ela', 'defenseur', 'mine grzmot', 2, 2, 'pologne'),
    (39, 'ying', 'assaillant', 'candela', 2, 2, 'chine'),
    (40, 'lesion', 'defenseur', 'gu', 2, 2, 'chine'),
    (41, 'mira', 'defenseur', 'miroir noir', 3, 1, 'espagne'),
    (42, 'jackal', 'assaillant', 'eyenox model', 2, 2, 'espagne'),
    (43, 'hibana', 'assaillant', 'x-kairos', 1, 3, 'japon'),
    (44, 'echo', 'defenseur', 'yokai', 2, 2, 'japon'),
    (45, 'caveira', 'defenseur', 'pas de velour', 1, 3, 'bresil'),
    (46, 'capitao', 'assaillant', 'arbalete tactique', 1, 3, 'bresil'),
    (47, 'blackbeard', 'assaillant', 'bouclier d arme', 2, 2, 'usa'),
    (48, 'valkyrie', 'defenseur', 'black eye', 2, 2, 'usa'),
    (49, 'buck', 'assaillant', 'passe-partout', 2, 2, 'canada'),
    (50, 'frost', 'defenseur', 'tapis rouge', 2, 2, 'colombie'),
    (51, 'mute', 'defenseur', 'brouilleur de signaux', 3, 1, 'angleterre'),
    (52, 'sledge', 'assaillant', 'masse', 3, 1, 'angleterre'),
    (53, 'smoke', 'defenseur', 'grenade a gaz telecomanmdee', 2, 2, 'angleterre'),
    (54, 'thatcher', 'assaillant', 'grenade iem', 3, 1, 'angleterre'),
    (55, 'ashe', 'assaillant', 'munition d infiltration', 1, 3, 'israel'),
    (56, 'castle', 'defenseur', 'panneau de blindage', 2, 2, 'usa'),
    (57, 'pulse', 'defenseur', 'capteur cardiaque', 1, 3, 'usa'),
    (58, 'thermite', 'assaillant', 'charge exothermique', 2, 2, 'usa'),
    (59, 'montagne', 'assaillant', 'bouclier le roc', 3, 1, 'france'),
    (60, 'twitch', 'assaillant', 'drone a electrocution', 2, 2, 'france'),
    (61, 'doc', 'defenseur', 'pistolet stim', 3, 1, 'france'),
    (62, 'rook', 'defenseur', 'sac de plaques de protection', 3, 1, 'france'),
    (63, 'jager', 'defenseur', 'defense active', 2, 2, 'allemagne'),
    (64, 'bandit', 'defenseur', 'fil electrifie', 1, 3, 'allemagne'),
    (65, 'blitz', 'assaillant', 'bouclier flash', 2, 2, 'allemagne'),
    (66, 'iq', 'assaillant', 'detecteur electronique', 1, 3, 'allemagne'),
    (67, 'fuze', 'assaillant', 'charge a sous-munition', 3, 1, 'russe'),
    (68, 'glaz', 'assaillant', 'visee auxiliaire', 2, 2, 'russe'),
    (69, 'tachanka', 'defenseur', 'lance-grenades-shumikha', 3, 1, 'russe'),
    (70, 'kapkan', 'defenseur', 'dispositif de blocage acces', 2, 2, 'russe');

--Table arme
INSERT INTO arme VALUES(1, 'mp5k', 'smg');
INSERT INTO arme VALUES(2, 'm590a1', 'fusil pompe');
INSERT INTO arme VALUES(3, 'fmg9', 'smg');
INSERT INTO arme VALUES(4, 'l85a2', 'fusil assault');
INSERT INTO arme VALUES(5, 'ar33', 'fusil assault');
INSERT INTO arme VALUES(6, 'g36c', 'fusil assault');
INSERT INTO arme VALUES(7, 'r4c', 'fusil assault');
INSERT INTO arme VALUES(8, 'ump45', 'smg');
INSERT INTO arme VALUES(9, 'm1014', 'fusil pompe');
INSERT INTO arme VALUES(10, '556xi', 'fusil assault');
INSERT INTO arme VALUES(11, 'leroc', 'bouclier');
INSERT INTO arme VALUES(12, 'f2', 'fusil assault');
INSERT INTO arme VALUES(13, '417', 'sniper');
INSERT INTO arme VALUES(14, 'sgcqb', 'fusil pompe');
INSERT INTO arme VALUES(15, 'p90', 'smg');
INSERT INTO arme VALUES(16, 'mp5', 'smg');
INSERT INTO arme VALUES(17, 'm870', 'fusil pompe');
INSERT INTO arme VALUES(18, '416c', 'fusil assault');
INSERT INTO arme VALUES(19, 'mp7', 'smg');
INSERT INTO arme VALUES(20, '552commando', 'fusil assault');
INSERT INTO arme VALUES(21, 'auga2', 'fusil assault');
INSERT INTO arme VALUES(22, 'g8a1', 'fusil mitrailleur');
INSERT INTO arme VALUES(23, 'g52tactical', 'bouclier');
INSERT INTO arme VALUES(24, 'ak12', 'fusil assault');
INSERT INTO arme VALUES(25, '6p41', 'fusil mitrailleur');
INSERT INTO arme VALUES(26, 'bouclierballistique', 'bouclier');
INSERT INTO arme VALUES(27, 'ots03', 'sniper');
INSERT INTO arme VALUES(28, 'dp27', 'fusil mitrailleur');
INSERT INTO arme VALUES(29, '9x19vsn', 'smg');
INSERT INTO arme VALUES(30, 'sasg12', 'fusil pompe');
INSERT INTO arme VALUES(31, 'super90', 'fusil pompe');
INSERT INTO arme VALUES(32, '9mmc1', 'smg');
INSERT INTO arme VALUES(33, 'c8sfw', 'fusil assault');
INSERT INTO arme VALUES(34, 'camrs', 'sniper');
INSERT INTO arme VALUES(35, 'mpx', 'smg');
INSERT INTO arme VALUES(36, 'spas12', 'fusil pompe');
INSERT INTO arme VALUES(37, 'mk17cqb', 'fusil assault');
INSERT INTO arme VALUES(38, 'sr25', 'sniper');
INSERT INTO arme VALUES(39, 'para308', 'fusil assault');
INSERT INTO arme VALUES(40, 'm249', 'fusil mitrailleur');
INSERT INTO arme VALUES(41, 'm12', 'smg');
INSERT INTO arme VALUES(42, 'spas15', 'fusil pompe');
INSERT INTO arme VALUES(43, 'mp5sd', 'smg');
INSERT INTO arme VALUES(44, 'supernova', 'fusil pompe');
INSERT INTO arme VALUES(45, 'type89', 'fusil assault');
INSERT INTO arme VALUES(46, 'c7e', 'fusil assault');
INSERT INTO arme VALUES(47, 'pdw9', 'smg');
INSERT INTO arme VALUES(48, 'ita12l', 'fusil pompe');
INSERT INTO arme VALUES(49, 'vector45acp', 'smg');
INSERT INTO arme VALUES(50, 'six12sd', 'fusil pompe');
INSERT INTO arme VALUES(51, 'six12', 'fusil pompe');
INSERT INTO arme VALUES(52, 't5smg', 'smg');
INSERT INTO arme VALUES(53, 't85lsw', 'fusil mitrailleur');
INSERT INTO arme VALUES(54, 'scorpionevo3a1', 'smg');
INSERT INTO arme VALUES(55, 'fo12', 'fusil pompe');
INSERT INTO arme VALUES(56, 'lmge', 'fusil mitrailleur');
INSERT INTO arme VALUES(57, 'm762', 'fusil assault');
INSERT INTO arme VALUES(58, 'mk14ebr', 'sniper');
INSERT INTO arme VALUES(59, 'bosg122', 'fusil pompe');
INSERT INTO arme VALUES(60, 'k1a', 'smg');
INSERT INTO arme VALUES(61, 'spear308', 'fusil assault');
INSERT INTO arme VALUES(62, 'v308', 'fusil assault');
INSERT INTO arme VALUES(63, 'mx4storm', 'smg');
INSERT INTO arme VALUES(64, 'acs12', 'fusil pompe');
INSERT INTO arme VALUES(65, 'alda556', 'fusil mitrailleur');
INSERT INTO arme VALUES(66, 'ar1550', 'sniper');
INSERT INTO arme VALUES(67, 'm4gs', 'fusil assault');
INSERT INTO arme VALUES(68, 'bouclieraee', 'bouclier');
INSERT INTO arme VALUES(69, 'auga3', 'smg');
INSERT INTO arme VALUES(70, 'tcsg12', 'fusil pompe');
INSERT INTO arme VALUES(71, 'ak74m', 'fusil assault');
INSERT INTO arme VALUES(72, 'arx200', 'fusil assault');
INSERT INTO arme VALUES(73, 'f90', 'fusil assault');
INSERT INTO arme VALUES(74, 'm249saw', 'fusil mitrailleur');
INSERT INTO arme VALUES(75, 'commando9', 'smg');
INSERT INTO arme VALUES(76, 'p10roni', 'smg');
INSERT INTO arme VALUES(77, 'csrx300', 'sniper');
INSERT INTO arme VALUES(78, 'sc3000k', 'fusil assault');
INSERT INTO arme VALUES(79, 'uzk50gi', 'fusil assault');
INSERT INTO arme VALUES(80, 'pof9', 'fusil assault');

-- Table gadget 
INSERT INTO gadget VALUES(81, 'assaillant', 'grenade fumigene');
INSERT INTO gadget VALUES(82, 'assaillant', 'grenade flash');
INSERT INTO gadget VALUES(83, 'defenseur', 'grenade percussion');
INSERT INTO gadget VALUES(84, 'defenseur', 'nitro');
INSERT INTO gadget VALUES(85, 'assaillant', 'grenade frag');
INSERT INTO gadget VALUES(86, 'assaillant', 'claymore');
INSERT INTO gadget VALUES(87, 'assaillant', 'explosifs');
INSERT INTO gadget VALUES(88, 'defenseur', 'fil barbele');
INSERT INTO gadget VALUES(89, 'defenseur', 'camera blindee');
INSERT INTO gadget VALUES(90, 'defenseur', 'alarme de proximite');
INSERT INTO gadget VALUES(91, 'assaillant', 'charge de breche lourde');
INSERT INTO gadget VALUES(92, 'defenseur', 'bouclier deployable');

-- Table carte
INSERT INTO carte (id_carte, nom_carte) VALUES (1, 'Labo de Nighhaven');
INSERT INTO carte (id_carte, nom_carte) VALUES (2, 'Stade');
INSERT INTO carte (id_carte, nom_carte) VALUES (3, 'Huis Clos');
INSERT INTO carte (id_carte, nom_carte) VALUES (4, 'Plaine d Emeraude');
INSERT INTO carte (id_carte, nom_carte) VALUES (5, 'Banque');
INSERT INTO carte (id_carte, nom_carte) VALUES (6, 'Frontiere');
INSERT INTO carte (id_carte, nom_carte) VALUES (7, 'Chalet');
INSERT INTO carte (id_carte, nom_carte) VALUES (8, 'Clubhouse');
INSERT INTO carte (id_carte, nom_carte) VALUES (9, 'Littoral');
INSERT INTO carte (id_carte, nom_carte) VALUES (10, 'Consulat');
INSERT INTO carte (id_carte, nom_carte) VALUES (11, 'Favela');
INSERT INTO carte (id_carte, nom_carte) VALUES (12, 'Forteresse');
INSERT INTO carte (id_carte, nom_carte) VALUES (13, 'Base d Hereford');
INSERT INTO carte (id_carte, nom_carte) VALUES (14, 'Maison');
INSERT INTO carte (id_carte, nom_carte) VALUES (15, 'Cafe Dostoyevsky');
INSERT INTO carte (id_carte, nom_carte) VALUES (16, 'Canal');
INSERT INTO carte (id_carte, nom_carte) VALUES (17, 'Oregon');
INSERT INTO carte (id_carte, nom_carte) VALUES (18, 'Outback');
INSERT INTO carte (id_carte, nom_carte) VALUES (19, 'Avion Presidentiel');
INSERT INTO carte (id_carte, nom_carte) VALUES (20, 'Gratte-Ciel');
INSERT INTO carte (id_carte, nom_carte) VALUES (21, 'Parc d Attraction');
INSERT INTO carte (id_carte, nom_carte) VALUES (22, 'Tour');
INSERT INTO carte (id_carte, nom_carte) VALUES (23, 'Villa');
INSERT INTO carte (id_carte, nom_carte) VALUES (24, 'Yatch');

--Table combat 
SET datestyle = 'ISO, DMY';
INSERT INTO combat VALUES(1,'1/4 finale', '22-06-2022', 'Wolves Esports' , 'Deathrow Academy' ,8 ,'0-2', 8);
INSERT INTO combat VALUES(2,'1/4 finale', '22-06-2022', 'Maestria' , 'Deathrow' ,3 ,'0-2',3);
INSERT INTO combat VALUES(3,'1/4 finale', '22-06-2022', 'Exalty' , 'MalaGanxts' ,5 ,'0-2',7);
INSERT INTO combat VALUES(4,'1/4 finale', '22-06-2022', 'ACEND' , 'WAFWAF' ,2 ,'2-0',11);
INSERT INTO combat VALUES(5,'1/2 finale', '24-06-2022', 'Deathrow Academy' , 'Deathrow' ,3 ,'0-2',8);
INSERT INTO combat VALUES(6,'1/2 finale', '24-06-2022','MalaGanxts' , 'ACEND' ,2 ,'0-2',1);
INSERT INTO combat VALUES(7,'finale', '26-06-2022', 'Deathrow' , 'ACEND' ,2 ,'1-2',5);

--Table avoir_participer 
insert into avoir_participer VALUES (1, 1, NULL, NULL, 3);
insert into avoir_participer VALUES (1, 2, NULL, NULL, 0);
insert into avoir_participer VALUES (2, 3, NULL, NULL, 3);
insert into avoir_participer VALUES (2, 4, NULL, NULL, 0);
insert into avoir_participer VALUES (3, 5, NULL, NULL, 3);
insert into avoir_participer VALUES (3, 6, NULL, NULL, 0);
insert into avoir_participer VALUES (4, 7, NULL, NULL, 3);
insert into avoir_participer VALUES (4, 8, NULL, NULL, 0);
insert into avoir_participer VALUES (5, 1, NULL, NULL, 3);
insert into avoir_participer VALUES (5, 3, NULL, NULL, 0);
insert into avoir_participer VALUES (6, 2, NULL, NULL, 3);
insert into avoir_participer VALUES (6, 4, NULL, NULL, 0);

--Table avoir_joue
INSERT INTO avoir_joue VALUES (1,2, 1, '22/06/2022', 4, 3, 5);
INSERT INTO avoir_joue VALUES (1,3, 1, '22/06/2022', 6, 2, 4);
INSERT INTO avoir_joue VALUES (1,4, 1, '22/06/2022', 7, 8, 3);
INSERT INTO avoir_joue VALUES (1,5, 1, '22/06/2022', 12, 0, 5);
INSERT INTO avoir_joue VALUES (8,36, 1, '22/06/2022', 70, 11, 5);
INSERT INTO avoir_joue VALUES (8,37, 1, '22/06/2022', 61, 5, 1);
INSERT INTO avoir_joue VALUES (8,38, 1, '22/06/2022', 41, 3, 5);
INSERT INTO avoir_joue VALUES (8,39, 1, '22/06/2022', 44, 3, 4);
INSERT INTO avoir_joue VALUES (8,40, 1, '22/06/2022', 29, 0, 3);
INSERT INTO avoir_joue VALUES (6,26, 2, '22/06/2022', 68, 0, 5);
INSERT INTO avoir_joue VALUES (6,27, 2, '22/06/2022', 49, 1, 5);
INSERT INTO avoir_joue VALUES (6,28, 2, '22/06/2022', 46, 2, 4);
INSERT INTO avoir_joue VALUES (6,29, 2, '22/06/2022', 58, 2, 4);
INSERT INTO avoir_joue VALUES (6,30, 2, '22/06/2022', 59, 1, 5);
INSERT INTO avoir_joue VALUES (3,11, 2, '22/06/2022', 70, 4, 0);
INSERT INTO avoir_joue VALUES (3,12, 2, '22/06/2022', 61, 13, 1);
INSERT INTO avoir_joue VALUES (3,13, 2, '22/06/2022', 41, 2, 1);
INSERT INTO avoir_joue VALUES (3,14, 2, '22/06/2022', 44, 3, 2);
INSERT INTO avoir_joue VALUES (3,15, 2, '22/06/2022', 29, 1, 2);
INSERT INTO avoir_joue VALUES (4,16, 3, '22/06/2022', 27, 4, 5);
INSERT INTO avoir_joue VALUES (4,17, 3, '22/06/2022', 15, 5, 5);
INSERT INTO avoir_joue VALUES (4,18, 3, '22/06/2022', 12, 3, 4);
INSERT INTO avoir_joue VALUES (4,19, 3, '22/06/2022', 39, 3, 4);
INSERT INTO avoir_joue VALUES (4,20, 3, '22/06/2022', 4, 6, 3);
INSERT INTO avoir_joue VALUES (5,21, 3, '22/06/2022', 70, 6, 5);
INSERT INTO avoir_joue VALUES (5,22, 3, '22/06/2022', 61, 6, 4);
INSERT INTO avoir_joue VALUES (5,23, 3, '22/06/2022', 41, 4, 4);
INSERT INTO avoir_joue VALUES (5,24, 3, '22/06/2022', 44, 2, 3);
INSERT INTO avoir_joue VALUES (5,25, 3, '22/06/2022', 29, 3, 5);
INSERT INTO avoir_joue VALUES (2,6, 4, '22/06/2022', 12, 8, 2);
INSERT INTO avoir_joue VALUES (2,7, 4, '22/06/2022', 23, 8, 2);
INSERT INTO avoir_joue VALUES (2,8, 4, '22/06/2022', 52, 2, 4);
INSERT INTO avoir_joue VALUES (2,9, 4, '22/06/2022', 58, 2, 2);
INSERT INTO avoir_joue VALUES (2,10, 4, '22/06/2022', 59, 5, 3);
INSERT INTO avoir_joue VALUES (7,31, 4, '22/06/2022', 70, 4, 5);
INSERT INTO avoir_joue VALUES (7,32, 4, '22/06/2022', 9, 2, 5);
INSERT INTO avoir_joue VALUES (7,33, 4, '22/06/2022', 48, 3, 5);
INSERT INTO avoir_joue VALUES (7,34, 4, '22/06/2022', 25, 3, 5);
INSERT INTO avoir_joue VALUES (7,35, 4, '22/06/2022', 50, 1, 5);
INSERT INTO avoir_joue VALUES (8,36, 5, '27/06/2022', 26, 5, 5);
INSERT INTO avoir_joue VALUES (8,37, 5, '27/06/2022', 15, 0, 5);
INSERT INTO avoir_joue VALUES (8,38, 5, '27/06/2022', 6, 1, 5);
INSERT INTO avoir_joue VALUES (8,39, 5, '27/06/2022', 55, 3, 5);
INSERT INTO avoir_joue VALUES (8,40, 5, '27/06/2022', 68, 0, 5);
INSERT INTO avoir_joue VALUES (3,11, 5, '27/06/2022', 70, 8, 2);
INSERT INTO avoir_joue VALUES (3,12, 5, '27/06/2022', 45, 5, 4);
INSERT INTO avoir_joue VALUES (3,13, 5, '27/06/2022', 44, 5, 1);
INSERT INTO avoir_joue VALUES (3,14, 5, '27/06/2022', 41, 5, 1);
INSERT INTO avoir_joue VALUES (3,15, 5, '27/06/2022', 13, 2, 1);
INSERT INTO avoir_joue VALUES (5,21, 6, '28/06/2022', 15, 6, 5);
INSERT INTO avoir_joue VALUES (5,22, 6, '28/06/2022', 34, 4, 4);
INSERT INTO avoir_joue VALUES (5,23, 6, '28/06/2022', 33, 4, 3);
INSERT INTO avoir_joue VALUES (5,24, 6, '28/06/2022', 58, 3, 5);
INSERT INTO avoir_joue VALUES (5,25, 6, '28/06/2022', 2, 2, 5);
INSERT INTO avoir_joue VALUES (2,6, 4, '28/06/2022', 70, 14, 4);
INSERT INTO avoir_joue VALUES (2,7, 4, '28/06/2022', 69, 2, 5);
INSERT INTO avoir_joue VALUES (2,8, 4, '28/06/2022', 64, 6, 4);
INSERT INTO avoir_joue VALUES (2,9, 4, '28/06/2022', 63, 0, 3);
INSERT INTO avoir_joue VALUES (2,10, 4, '28/06/2022', 1, 0, 3);
INSERT INTO avoir_joue VALUES (3,11, 5, '02/07/2022', 12, 7, 5);
INSERT INTO avoir_joue VALUES (3,12, 5, '02/07/2022', 27, 3, 4);
INSERT INTO avoir_joue VALUES (3,13, 5, '02/07/2022', 43, 3, 4);
INSERT INTO avoir_joue VALUES (3,14, 5, '02/07/2022', 36, 2, 4);
INSERT INTO avoir_joue VALUES (3,15, 5, '02/07/2022', 54, 6, 4);
INSERT INTO avoir_joue VALUES (2,6, 4, '02/07/2022', 69, 5, 4);
INSERT INTO avoir_joue VALUES (2,7, 4, '02/07/2022', 64, 4, 5);
INSERT INTO avoir_joue VALUES (2,8, 4, '02/07/2022', 35, 6, 4);
INSERT INTO avoir_joue VALUES (2,9, 4, '02/07/2022', 22, 2, 4);
INSERT INTO avoir_joue VALUES (2,10, 4, '02/07/2022', 19, 4, 4);