---------------------------------------
INSERT INTO diriger VALUES (1,1);
INSERT INTO diriger VALUES (2,1);
----------------------------------------
INSERT INTO diriger VALUES (3,2);
-----------------------------------------
INSERT INTO diriger VALUES (4,3);
INSERT INTO diriger VALUES (5,3);
----------------------------------------
INSERT INTO diriger VALUES (6,4);
---------------------------------------

--------------------------------------
INSERT INTO diriger VALUES (7,6);
---------------------------------------

---------------------------------------
INSERT INTO diriger VALUES (8,8);
INSERT INTO diriger VALUES (9,8);