--Fonction qui permet de mettre automatiquement en majuscule les joueurs
CREATE OR REPLACE FUNCTION insertion_joueur()
RETURNS TRIGGER AS
$$
BEGIN
    NEW.prenom_joueur = INITCAP(NEW.prenom_joueur);
    NEW.nom_joueur = INITCAP(NEW.nom_joueur);
    NEW.surnom_joueur = INITCAP(NEW.surnom_joueur);
    NEW.nationalite_joueur = UPPER(NEW.nationalite_joueur);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER majuscule_joueur
BEFORE INSERT OR UPDATE
ON joueur
FOR EACH ROW
EXECUTE FUNCTION insertion_joueur();

---------------------------------------------------------------------------------------------------------
--Fonction qui permet de mettre automatiquement en majuscule les coachs
CREATE OR REPLACE FUNCTION insertion_coach()
RETURNS TRIGGER AS
$$
BEGIN
    NEW.prenom_coach = INITCAP(NEW.prenom_coach);
    NEW.nom_coach = INITCAP(NEW.nom_coach);
    NEW.surnom_coach = INITCAP(NEW.surnom_coach);
    NEW.nationalite_coach = UPPER(NEW.nationalite_coach);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER majuscule_coach
BEFORE INSERT OR UPDATE
ON coach
FOR EACH ROW
EXECUTE FUNCTION insertion_coach();

---------------------------------------------------------------------------------------------------------
--Fonction qui permet de mettre automatiquement des majuscules lors de l'insertion d'une equipe
CREATE OR REPLACE FUNCTION insertion_equipe()
RETURNS TRIGGER AS
$$
BEGIN
    NEW.nom_equipe = INITCAP(SPLIT_PART(NEW.nom_equipe, ' ', 1)) || ' ' || INITCAP(SPLIT_PART(NEW.nom_equipe, ' ', 2));
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER majuscule_equipe
BEFORE INSERT OR UPDATE
ON equipe
FOR EACH ROW
EXECUTE FUNCTION insertion_equipe();

---------------------------------------------------------------------------------------------------------
--Fonction qui permet de mettre automatiquement des majuscule une arme 
CREATE OR REPLACE FUNCTION insertion_arme()
RETURNS TRIGGER AS
$$
BEGIN
    NEW.nom_arme = INITCAP(SPLIT_PART(NEW.nom_arme, ' ', 1)) || ' ' || INITCAP(SPLIT_PART(NEW.nom_arme, ' ', 2));
    NEW.type_arme = INITCAP(SPLIT_PART(NEW.type_arme, ' ', 1)) || ' ' || INITCAP(SPLIT_PART(NEW.type_arme, ' ', 2));

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER majuscule_arme
BEFORE INSERT OR UPDATE
ON arme
FOR EACH ROW
EXECUTE FUNCTION insertion_arme();

---------------------------------------------------------------------------------------------------------
--Fonction qui permet de mettre en majuscule des nouveaux gadget 
CREATE OR REPLACE FUNCTION insertion_gadget()
RETURNS TRIGGER AS
$$
BEGIN
    NEW.nom_gadget = INITCAP(SPLIT_PART(NEW.nom_gadget, ' ', 1)) || ' ' || INITCAP(SPLIT_PART(NEW.nom_gadget, ' ', 2));
    NEW.type_gadget = INITCAP(SPLIT_PART(NEW.type_gadget, ' ', 1)) || ' ' || INITCAP(SPLIT_PART(NEW.type_gadget, ' ', 2));

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER majuscule_gadget
BEFORE INSERT OR UPDATE
ON gadget
FOR EACH ROW
EXECUTE FUNCTION insertion_gadget();

---------------------------------------------------------------------------------------------------------
--Procedure qui permet d'ajouter des joueurs professionel
CREATE OR REPLACE PROCEDURE ajout_joueur(nom VARCHAR(30), prenom VARCHAR(30), surnom VARCHAR(30), nationalite VARCHAR(30))
AS $$
DECLARE
    new_id INT;
BEGIN
    SELECT id_joueur INTO new_id FROM joueur ORDER BY id_joueur DESC LIMIT 1;
    INSERT INTO joueur VALUES (new_id + 1, prenom, nom, surnom, nationalite);
END;
$$ LANGUAGE plpgsql;

---------------------------------------------------------------------------------------------------------
--Procedure qui permet d'ajouter des heros
CREATE OR REPLACE PROCEDURE ajout_heros(nom_heros VARCHAR(30), affiliation VARCHAR(30), competence VARCHAR(30), sante int, vitesse int, nationalite VARCHAR(30))
AS $$
DECLARE
    new_id INT;
BEGIN
    SELECT id_heros INTO new_id FROM heros ORDER BY id_heros DESC LIMIT 1;
    INSERT INTO heros VALUES (new_id + 1, nom_heros, affiliation, sante, vitesse, nationalite);
END;
$$ LANGUAGE plpgsql;

---------------------------------------------------------------------------------------------------------
--Procedure qui permet d'ajouter des equipes
CREATE OR REPLACE PROCEDURE ajout_equipe(nom_equipe VARCHAR(30))
AS $$
DECLARE
    new_id INT;
BEGIN
    SELECT id_equipe INTO new_id FROM equipe ORDER BY id_equipe DESC LIMIT 1;
    INSERT INTO joueur VALUES (new_id + 1, nom_equipe);
END;
$$ LANGUAGE plpgsql;

---------------------------------------------------------------------------------------------------------
--Procedure qui permet d'ajouter des joueurs dans une equipe
CREATE OR REPLACE PROCEDURE ajout_joueur_equipe(nomequipe VARCHAR(30), surnom_joueur_1 VARCHAR(30))
AS $$
DECLARE
    new_id INT;
    new_joueur INT;
BEGIN
    SELECT id_equipe INTO new_id FROM equipe WHERE nom_equipe=nomequipe;
    SELECT id_joueur INTO new_joueur FROM joueur WHERE surnom_joueur=surnom_joueur_1;
    INSERT INTO appartenir VALUES (new_joueur, new_id);
END;
$$ LANGUAGE plpgsql;

---------------------------------------------------------------------------------------------------------
--Procedure qui permet d'ajouter des coachs
CREATE OR REPLACE PROCEDURE ajout_coach_equipe(nomequipe VARCHAR(30), surnom_coach_1 VARCHAR(30))
AS $$
DECLARE
    new_id INT;
    new_coach INT;
BEGIN
    SELECT id_equipe INTO new_id FROM equipe WHERE nom_equipe=nomequipe;
    SELECT id_coach INTO new_coach FROM coach WHERE surnom_coach=surnom_coach_1;
    INSERT INTO appartenir VALUES (new_coach, new_id);
END;
$$ LANGUAGE plpgsql;


---------------------------------------------------------------------------------------------------------
--Fonction qui permet avec les deux noms d'equipe de chercher l'id du combat s'il existe, cette fonction est la plus
--importante car elle est réutiliser dans d'autre fonction
CREATE OR REPLACE FUNCTION get_combat_id(equipe1_nom VARCHAR(30), equipe2_nom VARCHAR(30))
RETURNS INT AS 
$$
DECLARE
    equipe1_id INT;
    equipe2_id INT;
    combat_id INT;
BEGIN
    -- Trouver les id_equipe pour les noms d'équipe fournis
    SELECT id_equipe INTO equipe1_id FROM equipe WHERE nom_equipe LIKE equipe1_nom;
    SELECT id_equipe INTO equipe2_id FROM equipe WHERE nom_equipe LIKE equipe2_nom;

    -- Trouver l'id_combat correspondant aux deux équipes
    SELECT C.id_combat INTO combat_id
    FROM combat AS C
    INNER JOIN avoir_participer AS P1 ON C.id_combat = P1.id_combat
    INNER JOIN avoir_participer AS P2 ON C.id_combat = P2.id_combat
    WHERE P1.id_equipe = equipe1_id AND P2.id_equipe = equipe2_id;

    RETURN combat_id;
END;
$$ LANGUAGE plpgsql;

---------------------------------------------------------------------------------------------------------
-- Fonction qui permet de renvoyer la date du combat entre deux equipes si elle existe 
CREATE OR REPLACE FUNCTION return_date_combat(equipe1_nom VARCHAR(30), equipe2_nom VARCHAR(30))
RETURNS DATE AS 
$$
DECLARE
    combat_id INT;
    date_trouver DATE;
BEGIN
    SELECT get_combat_id(equipe1_nom, equipe2_nom) into combat_id;
    SELECT date_combat into date_trouver FROM combat WHERE id_combat=combat_id;
    
    RETURN date_trouver;
END;
$$ LANGUAGE plpgsql;


-- Utilisation de la fonction
SELECT return_date_combat('Wolves Esports', 'ACEND');

--Ici peut importe l'ordre des deux equipes mise dans la requête la fonction est fait pour
--renvoyer la date de combat ou a eu lieu le duel entre les deux equipes
 return_date_combat
--------------------
 2004-04-22
(1 ligne)

SELECT return_date_combat('ACEND', 'Wolves Esports');
 
 return_date_combat
--------------------
 2004-04-22
(1 ligne)

---------------------------------------------------------------------------------------------------------
--Fonction qui permet de renvoyé la liste des joueurs celon le nom d'équipe choisit

CREATE OR REPLACE FUNCTION liste_joueur(equipe1_nom VARCHAR(30), equipe2_nom VARCHAR(30))
RETURNS TABLE (equipe1_joueurs VARCHAR[], equipe2_joueurs VARCHAR[])
AS $$
BEGIN
    RETURN QUERY
    SELECT
        ARRAY(SELECT j.surnom_joueur
              FROM joueur j
              INNER JOIN appartenir a ON j.id_joueur = a.id_joueur
              INNER JOIN equipe e ON a.id_equipe = e.id_equipe
              WHERE e.nom_equipe = equipe1_nom) AS equipe1_joueurs,
        ARRAY(SELECT j.surnom_joueur
              FROM joueur j
              INNER JOIN appartenir a ON j.id_joueur = a.id_joueur
              INNER JOIN equipe e ON a.id_equipe = e.id_equipe
              WHERE e.nom_equipe = equipe2_nom) AS equipe2_joueurs;

    RETURN;
END;
$$ LANGUAGE plpgsql;

-- Utilisation de la fonction
SELECT liste_joueur('Wolves Esports', 'ACEND');

-- Ici le retour se fait sous la forme (joueur1,joueur2,joueur3,joueur4,joueur5)","(joueur1,joueur2,joueur3,joueur4,joueur5)
--Les joueurs de gauche sont les joueurs de l'equipe de gauche et à droite les joueurs de l'equipe a droite
                                   liste_joueur
----------------------------------------------------------------------------------
 ("{biBoo,risze,P4,Shiinka,Mowwwgli}","{""ENEMY,"",RevaN,Kaktus,DEADSHT,Ra1kos}")
(1 ligne)

SELECT liste_joueur('ACEND', 'Wolves Esports');

                                   liste_joueur
----------------------------------------------------------------------------------
 ("{""ENEMY,"",RevaN,Kaktus,DEADSHT,Ra1kos}","{biBoo,risze,P4,Shiinka,Mowwwgli}")
(1 ligne)


---------------------------------------------------------------------------------------------
-- Fonction qui permet de renvoyé le nom des équipes celon l'id rentrée 

CREATE OR REPLACE FUNCTION Nom_equipes(p_id_equipes INT[])
RETURNS TABLE (id_equipe INT, nom_equipe VARCHAR(30))
AS $$
BEGIN
    RETURN QUERY
    SELECT
        e.id_equipe,
        e.nom_equipe
    FROM
        equipe e
    WHERE
        e.id_equipe = ANY(p_id_equipes);

    RETURN;
END;
$$ LANGUAGE plpgsql;

--Utilisation de la Fonction--
SELECT * FROM Nom_equipes(ARRAY[1, 2, 3, 4, 5, 6, 7, 8 ]);

sae_web=> SELECT * FROM Nom_equipes(ARRAY[1, 2, 3, 4, 5, 6, 7, 8 ]);
 id_equipe |    nom_equipe
-----------+------------------
         1 | Wolves Esports
         2 | ACEND
         3 | DeathroW
         4 | Exalty
         5 | MalaGanxst
         6 | Maestria
         7 | WAFWAF
         8 | deathroW academy
(8 lignes)

-----------------------------------------------------------------------
-- Fonction qui retourne le score des deux equipes choisit 
CREATE OR REPLACE FUNCTION calculer_score_combat(equipe1_nom VARCHAR(30), equipe2_nom VARCHAR(30)) 
RETURNS TABLE (score_equipe1 INT, score_equipe2 INT) AS $$
DECLARE
    score_equipe1 INT;
    score_equipe2 INT;
    combat_id INT;
BEGIN
    SELECT get_combat_id(equipe1_nom, equipe2_nom) INTO combat_id;
    
    IF combat_id IS NOT NULL THEN
        -- Calcul du score pour l'équipe 1 en fonction du nombre total de manches gagnées
        SELECT COALESCE(SUM(ap.manche_gagné), 0) AS total_manche_gagnees INTO score_equipe1
        FROM avoir_participer ap
        WHERE ap.id_combat = combat_id AND ap.id_equipe = (SELECT id_equipe FROM equipe WHERE nom_equipe = equipe1_nom);

        -- Calcul du score pour l'équipe 2 en fonction du nombre total de manches gagnées
        SELECT COALESCE(SUM(ap.manche_gagné), 0) AS total_manche_gagnees INTO score_equipe2
        FROM avoir_participer ap
        WHERE ap.id_combat = combat_id AND ap.id_equipe = (SELECT id_equipe FROM equipe WHERE nom_equipe = equipe2_nom);
    ELSE
        -- Gestion du cas où le combat_id n'est pas trouvé
        -- Vous pouvez ajouter un traitement spécifique ici si nécessaire
        RAISE EXCEPTION 'Combat non trouvé pour les équipes spécifiées';
    END IF;

    RETURN QUERY SELECT score_equipe1, score_equipe2;
END;
$$ LANGUAGE plpgsql;

--Utilisation de la Fonction--
SELECT calculer_score_combat('Wolves Esports', 'ACEND'); 
 
 -- Le retour de la fonction se fait en fonction du score de l'equipe ici le 3,0 signifie que Wolves Esports ont
 --gagné 3-0 contre l'equipe ACEND

 calculer_score_combat
-----------------------
 (3,0)
(1 ligne)


SELECT calculer_score_combat('ACEND', 'Wolves Esports'); 

 calculer_score_combat
-----------------------
 (0,3)
(1 ligne)

---------------------------------------------------------------------------------------------------------

