DROP TABLE IF EXISTS joueur CASCADE;
DROP TABLE IF EXISTS coach CASCADE;
DROP TABLE IF EXISTS appartenir CASCADE;
DROP TABLE IF EXISTS diriger CASCADE;
DROP TABLE IF EXISTS equipe CASCADE;
DROP TABLE IF EXISTS heros CASCADE;
DROP TABLE IF EXISTS carte CASCADE;
DROP TABLE IF EXISTS equipement CASCADE;
DROP TABLE IF EXISTS gadget CASCADE;
DROP TABLE IF EXISTS avoir_joue CASCADE;
DROP TABLE IF EXISTS avoir_participer CASCADE;
DROP TABLE IF EXISTS combat CASCADE;
DROP TABLE IF EXISTS recompense CASCADE;

CREATE TABLE joueur (
    id_joueur INT PRIMARY KEY,
    prenom_joueur VARCHAR(30) NULL,
    nom_joueur VARCHAR(30) NULL,
    surnom_joueur VARCHAR(30),
    nationalite_joueur VARCHAR(30)
);

CREATE TABLE coach (
    id_coach INT PRIMARY KEY,
    prenom_coach VARCHAR(30) NULL,
    nom_coach VARCHAR(30) NULL,
    surnom_coach VARCHAR(30),
    nationalite_coach VARCHAR(30)
);

CREATE TABLE equipe (
    id_equipe int PRIMARY KEY,
    nom_equipe VARCHAR(30) NOT NULL
);


CREATE TABLE appartenir (
    id_joueur INT,
    id_equipe INT,
    PRIMARY KEY (id_joueur, id_equipe),
    FOREIGN KEY (id_joueur) REFERENCES joueur(id_joueur),
    FOREIGN KEY (id_equipe) REFERENCES equipe(id_equipe)
);

CREATE TABLE diriger (
    id_coach INT,
    id_equipe INT,

    PRIMARY KEY (id_coach, id_equipe),
    FOREIGN KEY (id_coach) REFERENCES coach(id_coach),
    FOREIGN KEY (id_equipe) REFERENCES equipe(id_equipe)
);

CREATE TABLE heros (
    id_heros INT PRIMARY KEY,
    nom_heros VARCHAR(30),
    affiliation VARCHAR(30),
    capacite VARCHAR(70),
    sante INT,
    vitesse INT,
    nationalite VARCHAR(30)
);

CREATE TABLE equipement (
    id_equipment INT PRIMARY KEY
);

CREATE TABLE arme (
    nom_arme VARCHAR(30) NOT NULL,
    type_arme VARCHAR(30) NOT NULL
) INHERITS (equipement);

CREATE TABLE gadget (
    appartenance VARCHAR(30) NOT NULL,
    nom_gadget VARCHAR(30) NOT NULL
) INHERITS (equipement);

CREATE TABLE carte (
    id_carte INT PRIMARY KEY,
    nom_carte VARCHAR(255) NOT NULL
);


CREATE TABLE combat (
    id_combat INT PRIMARY KEY,
    qualification VARCHAR(255),
    date_combat DATE,
    equipeA VARCHAR(255),
    equipeB VARCHAR(255),
    equipe_gagnante INT ,
    score VARCHAR(255),
    id_carte INT,
    FOREIGN KEY (equipe_gagnante) REFERENCES equipe(id_equipe),
    FOREIGN KEY (id_carte) REFERENCES carte(id_carte)
);

CREATE TABLE avoir_participer (
    id_combat INT,
    id_equipe INT,
    kill_equipe INT NULL,
    mort_equipe INT NULL,
    manche_gagné INT,
    PRIMARY KEY (id_combat, id_equipe),
    FOREIGN KEY (id_combat) REFERENCES combat(id_combat),
    FOREIGN KEY (id_equipe) REFERENCES equipe(id_equipe)
);

CREATE TABLE avoir_joue (
    id_joueur INT,
    id_combat INT,
    date_combat date,
    id_heros INT,
    kill_joueur INT,
    mort_joueur INT,
    PRIMARY KEY (id_joueur, id_combat, date_combat),
    FOREIGN KEY (id_combat) REFERENCES combat(id_combat),
    FOREIGN KEY (id_joueur) REFERENCES joueur(id_joueur),
    FOREIGN KEY (id_heros) REFERENCES heros(id_heros)
);

CREATE TABLE recompense (
    id_recompense INT,
    id_equipe INT,
    recompense INT,
    PRIMARY KEY (id_recompense),
    FOREIGN KEY (id_equipe) REFERENCES equipe(id_equipe)
);
